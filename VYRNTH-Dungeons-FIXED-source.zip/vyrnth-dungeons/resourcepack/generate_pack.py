#!/usr/bin/env python3
"""
VYRNTH resource pack generator (pure Python 3, no dependencies).

  python3 generate_pack.py [output_dir]      -> writes the pack folder
  python3 generate_pack.py [output_dir] --zip -> also writes <output_dir>.zip

Everything (textures, models, blockstates, item definitions) is generated procedurally, so you can
re-run it after editing palettes, or just replace PNGs in assets/vyrnth/textures with hand-painted art.

IMPORTANT: BLOCKS order must match net.vyrnth.dungeons.CBlock (note = index + 1).
"""
import json, math, os, random, struct, sys, zipfile, zlib

OUT = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else "VYRNTH-Resourcepack"
MAKE_ZIP = "--zip" in sys.argv
S = 32  # texture size

# (id, model type) -- ORDER = CBlock enum order
BLOCKS = [
    ("ruin_brick", "all"),
    ("carved_runestone", "all"),
    ("flagstone", "all"),
    ("sigil_floor", "all"),
    ("gilded_pillar", "column"),
    ("ancient_gold", "all"),
    ("overgrown_ruin", "all"),
    ("bone_mortar", "all"),
    ("ritual_seal", "all"),
    ("gateway_stone", "all"),
    ("gateway_glyph", "all"),
    ("void_obsidian", "all"),
    ("brazier", "column"),
    ("eclipse_tile", "all"),
]
INSTRUMENTS = ["harp", "basedrum", "snare", "hat", "bass", "flute", "bell", "guitar", "chime", "xylophone",
               "iron_xylophone", "cow_bell", "didgeridoo", "bit", "banjo", "pling", "zombie", "skeleton",
               "creeper", "dragon", "wither_skeleton", "piglin", "custom_head"]

# ------------------------------------------------------------------ png writer
def write_png(path, w, h, rows):
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))

def clamp(v): return max(0, min(255, int(v)))
def mix(a, b, t): return tuple(clamp(a[i] + (b[i] - a[i]) * t) for i in range(3))
def shade(c, k): return tuple(clamp(v * k) for v in c)

def hsh(x, y, seed):
    v = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    v = ((v ^ (v >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((v ^ (v >> 16)) & 0xFFFF) / 65535.0

def vnoise(x, y, seed, scale=4):
    gx, gy = x / scale, y / scale
    x0, y0 = int(math.floor(gx)), int(math.floor(gy))
    fx, fy = gx - x0, gy - y0
    fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    a, b = hsh(x0, y0, seed), hsh(x0 + 1, y0, seed)
    c, d = hsh(x0, y0 + 1, seed), hsh(x0 + 1, y0 + 1, seed)
    return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy

def tile(fn, size=S):
    return [[fn(x, y) + (255,) if len(fn(x, y)) == 3 else fn(x, y) for x in range(size)] for y in range(size)]

# ------------------------------------------------------------------ texture painters
def t_bricks(base, mortar, seed, moss=0.0):
    bh, bw = S // 4, S // 2
    def f(x, y):
        row = y // bh
        xo = (x + (bw // 2 if row % 2 else 0)) % S
        col = xo // bw
        edge = (y % bh == 0) or (xo % bw == 0)
        if edge: return mixn(mortar, x, y, seed + 1, 0.15)
        tint = hsh(row, col, seed)
        c = shade(base, 0.82 + tint * 0.32)
        c = shade(c, 0.9 + vnoise(x, y, seed, 3) * 0.2)
        if (y % bh == 1) or (xo % bw == 1): c = shade(c, 1.12)
        if (y % bh == bh - 1) or (xo % bw == bw - 1): c = shade(c, 0.8)
        if moss and vnoise(x, y, seed + 7, 5) < moss: c = mix(c, (60, 110, 70), 0.75)
        return c
    return tile(f)

def mixn(c, x, y, seed, amt):
    n = vnoise(x, y, seed, 2) - 0.5
    return tuple(clamp(v * (1 + n * amt * 2)) for v in c)

def glow_overlay(base_fn, glyph_fn, color, strength=1.0):
    def f(x, y):
        c = base_fn(x, y)
        g = glyph_fn(x, y)
        if g > 0: c = mix(c, color, min(1, g * strength))
        return c
    return f

def rune(x, y):
    # simple concentric-arc rune with a cross stroke, in a 32x32 cell
    cx = cy = S / 2 - 0.5
    d = math.hypot(x - cx, y - cy)
    a = math.atan2(y - cy, x - cx)
    v = 0.0
    if 8.5 < d < 10.0 and not (-0.5 < math.sin(a * 2) < 0.2): v = 1.0
    if 3.5 < d < 4.8: v = max(v, 0.9)
    if abs(x - cx) < 0.9 and 4 < abs(y - cy) < 14: v = max(v, 0.9)
    if abs(y - cy) < 0.9 and 4 < abs(x - cx) < 7.5: v = max(v, 0.8)
    return v

def t_flagstone(seed):
    pts = [(hsh(i, 1, seed) * S, hsh(i, 2, seed) * S) for i in range(7)]
    def f(x, y):
        best, second, idx = 1e9, 1e9, 0
        for i, (px, py) in enumerate(pts):
            for ox in (-S, 0, S):
                for oy in (-S, 0, S):
                    d = math.hypot(x - px - ox, y - py - oy)
                    if d < best: second, best, idx = best, d, i
                    elif d < second: second = d
        if second - best < 1.3: return shade((30, 32, 40), 0.9 + hsh(x, y, seed) * 0.2)
        c = shade((84, 88, 104), 0.8 + hsh(idx, 9, seed) * 0.35)
        return shade(c, 0.9 + vnoise(x, y, seed, 3) * 0.25)
    return tile(f)

def t_sigil_floor(seed):
    base = lambda x, y: shade((40, 38, 58), 0.85 + vnoise(x, y, seed, 3) * 0.3)
    def g(x, y):
        cx = cy = S / 2 - 0.5
        d = math.hypot(x - cx, y - cy)
        v = 0.0
        if 11 < d < 12.4: v = 1.0
        if 6 < d < 7.2: v = 0.8
        ang = math.atan2(y - cy, x - cx)
        for k in range(3):
            if abs(math.sin(ang * 1.5 + k * 2.094)) < 0.06 and 2 < d < 11: v = max(v, 0.9)
        return v
    return tile(glow_overlay(base, g, (140, 100, 255)))

def t_gold(seed):
    def f(x, y):
        c = shade((200, 160, 60), 0.85 + vnoise(x, y, seed, 3) * 0.3)
        e = min(x, y, S - 1 - x, S - 1 - y)
        if e == 0: return shade(c, 0.55)
        if e == 1: return shade(c, 1.25)
        if 6 <= e <= 7 and (x + y) % 4 < 2: return shade(c, 0.7)
        return c
    return tile(f)

def t_bone(seed):
    def f(x, y):
        n = vnoise(x, y, seed, 4)
        c = mix((196, 188, 168), (150, 140, 120), n)
        if hsh(x // 3, y // 3, seed) < 0.18: c = shade(c, 0.7)
        if hsh(x, y, seed + 3) < 0.04: c = (235, 228, 210)
        return c
    return tile(f)

def t_obsidian(seed):
    def f(x, y):
        c = shade((22, 14, 34), 0.8 + vnoise(x, y, seed, 3) * 0.7)
        if hsh(x, y, seed) < 0.03: c = (120, 80, 220)
        return c
    return tile(f)

def t_gateway_stone(seed):
    def f(x, y):
        c = shade((52, 58, 74), 0.8 + vnoise(x, y, seed, 3) * 0.45)
        e = min(x, y, S - 1 - x, S - 1 - y)
        if e == 0: return shade(c, 0.5)
        if e in (3, 4): return mix(c, (214, 170, 70), 0.85)
        return c
    return tile(f)

def t_eclipse(seed):
    def f(x, y):
        cx = cy = S / 2 - 0.5
        d = math.hypot(x - cx, y - cy)
        c = shade((26, 20, 44), 0.8 + vnoise(x, y, seed, 3) * 0.4)
        if d < 3: return (230, 190, 90)
        if 6 < d < 7.2 or 12 < d < 13: return (130, 90, 230)
        if 9 < d < 9.8: return (214, 170, 70)
        return c
    return tile(f)

def t_pillar_side(seed):
    def f(x, y):
        c = shade((86, 88, 104), 0.85 + vnoise(x, y, seed, 4) * 0.3)
        if x % 8 == 0: c = shade(c, 0.7)
        if y < 3 or y > S - 4 or 14 <= y <= 17:
            g = shade((214, 172, 74), 0.85 + vnoise(x, y, seed, 2) * 0.3)
            return shade(g, 0.6) if y in (0, S - 1, 14, 17) and False else g
        return c
    return tile(f)

def t_pillar_end(seed):
    def f(x, y):
        cx = cy = S / 2 - 0.5
        d = max(abs(x - cx), abs(y - cy))
        if d > 14: return shade((214, 172, 74), 0.9)
        if d > 11: return shade((86, 88, 104), 0.8)
        return shade((60, 62, 78), 0.9 + vnoise(x, y, seed, 3) * 0.3)
    return tile(f)

def t_brazier_side(seed):
    def f(x, y):
        c = shade((34, 34, 44), 0.8 + vnoise(x, y, seed, 3) * 0.4)
        if y < 4: return shade((90, 92, 108), 0.9)
        if 10 < y < 22:
            g = abs(math.sin(x * 0.5)) * 0.5 + vnoise(x, y, seed, 3)
            return mix(c, (60, 200, 220), 0.35 + 0.35 * g)
        return c
    return tile(f)

def t_brazier_top(seed):
    def f(x, y):
        cx = cy = S / 2 - 0.5
        d = math.hypot(x - cx, y - cy)
        if d > 13: return shade((34, 34, 44), 1.0)
        t = d / 13
        return mix((220, 255, 255), (30, 150, 200), t)
    return tile(f)

def anim(fn_factory, frames):
    rows = []
    for k in range(frames):
        fr = tile(fn_factory(k / frames))
        rows.extend(fr)
    return rows

def t_seal_frames(seed, frames=8):
    def factory(ph):
        pulse = 0.5 + 0.5 * math.sin(ph * math.tau)
        base = lambda x, y: shade((30, 24, 48), 0.8 + vnoise(x, y, seed, 3) * 0.5)
        def g(x, y):
            v = rune(x, y)
            e = min(x, y, S - 1 - x, S - 1 - y)
            if e in (1, 2): v = max(v, 0.6)
            return v * (0.55 + 0.45 * pulse)
        return glow_overlay(base, g, (170, 110, 255), 1.0)
    return anim(factory, frames)

def t_glyph_frames(seed, frames=8):
    def factory(ph):
        pulse = 0.5 + 0.5 * math.sin(ph * math.tau)
        base = lambda x, y: shade((40, 46, 62), 0.8 + vnoise(x, y, seed, 3) * 0.4)
        def g(x, y):
            return rune(x, y) * (0.5 + 0.5 * pulse)
        return glow_overlay(base, g, (60, 240, 235), 1.0)
    return anim(factory, frames)

def t_membrane_frames(frames=16):
    def factory(ph):
        def f(x, y):
            u, v = x / S, y / S
            a = math.sin((v * 5 + ph * 2) * math.tau * 0.5 + math.sin(u * 6 + ph * math.tau) * 1.2)
            b = math.sin((u * 4 - ph * 2) * math.tau * 0.5 + math.cos(v * 5 + ph * math.tau))
            t = (a + b) * 0.25 + 0.5
            c = mix((110, 70, 255), (45, 226, 230), t)
            # soft edge fade so the plane blends with the arch
            e = min(u, 1 - u, v, 1 - v)
            alpha = clamp((110 + 90 * t) * min(1.0, e * 7))
            if hsh(x, y, int(ph * 100)) < 0.03: c, alpha = (255, 255, 255), 230
            return (c[0], c[1], c[2], alpha)
        return f
    return anim(factory, frames)

# --- 16x16 item icons (drawn small, as vanilla items are)
def icon(path, fn, size=16):
    write_png(path, size, size, [[fn(x, y) for x in range(size)] for y in range(size)])

def gem(color, dark, shape):
    def f(x, y):
        cx = cy = 7.5
        dx, dy = x - cx, y - cy
        if shape == "diamond": inside = abs(dx) + abs(dy) < 7
        elif shape == "orb": inside = math.hypot(dx, dy) < 6.5
        else: inside = abs(dx) < 4.5 + (y - 2) * 0.2 and 2 <= y <= 13 and abs(dx) + abs(dy) * 0.4 < 7.5
        if not inside: return (0, 0, 0, 0)
        edge = (abs(dx) + abs(dy) > 6) if shape == "diamond" else (math.hypot(dx, dy) > 5.4)
        c = dark if edge else mix(color, (255, 255, 255), max(0, 0.6 - (abs(dx + 2) + abs(dy + 2)) / 12))
        return (c[0], c[1], c[2], 255)
    return f

# ------------------------------------------------------------------ build
def jwrite(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f: json.dump(obj, f, indent=1)

def main():
    root = OUT
    tex = os.path.join(root, "assets/vyrnth/textures")
    mdl = os.path.join(root, "assets/vyrnth/models")
    itm = os.path.join(root, "assets/vyrnth/items")
    seed = 7731

    jwrite(os.path.join(root, "pack.mcmeta"), {"pack": {
        "pack_format": 46, "supported_formats": [46, 2147483647],
        "description": "\u00a75VYRNTH \u00a77- assets of a forgotten realm"}})

    def blk(name, rows, w=S, h=None):
        write_png(os.path.join(tex, "block", name + ".png"), w, h or len(rows), rows)

    blk("ruin_brick", t_bricks((92, 102, 118), (26, 30, 38), seed + 1))
    blk("carved_runestone", tile(glow_overlay(lambda x, y: tile_px(t_bricks((70, 78, 94), (24, 28, 36), seed + 2), x, y), rune, (60, 235, 230), 0.95)))
    blk("flagstone", t_flagstone(seed + 3))
    blk("sigil_floor", t_sigil_floor(seed + 4))
    blk("gilded_pillar_side", t_pillar_side(seed + 5))
    blk("gilded_pillar_end", t_pillar_end(seed + 5))
    blk("ancient_gold", t_gold(seed + 6))
    blk("overgrown_ruin", t_bricks((88, 98, 108), (24, 30, 30), seed + 7, moss=0.45))
    blk("bone_mortar", t_bone(seed + 8))
    blk("ritual_seal", t_seal_frames(seed + 9), S, S * 8)
    jwrite(os.path.join(tex, "block", "ritual_seal.png.mcmeta"), {"animation": {"frametime": 6, "interpolate": True}})
    blk("gateway_stone", t_gateway_stone(seed + 10))
    blk("gateway_glyph", t_glyph_frames(seed + 11), S, S * 8)
    jwrite(os.path.join(tex, "block", "gateway_glyph.png.mcmeta"), {"animation": {"frametime": 6, "interpolate": True}})
    blk("void_obsidian", t_obsidian(seed + 12))
    blk("brazier_side", t_brazier_side(seed + 13))
    blk("brazier_top", t_brazier_top(seed + 13))
    blk("eclipse_tile", t_eclipse(seed + 14))
    blk("portal_membrane", t_membrane_frames(16), S, S * 16)
    jwrite(os.path.join(tex, "block", "portal_membrane.png.mcmeta"), {"animation": {"frametime": 3, "interpolate": True}})

    # items
    icon(os.path.join(tex, "item", "ui_pane.png"), lambda x, y: (18, 14, 28, 255) if (x + y) % 5 else (26, 20, 42, 255))
    icon(os.path.join(tex, "item", "icon_default.png"), gem((140, 100, 255), (40, 24, 90), "diamond"))
    icon(os.path.join(tex, "item", "icon_reliquary.png"), gem((45, 226, 230), (20, 70, 110), "diamond"))
    icon(os.path.join(tex, "item", "recall_sigil.png"), gem((160, 190, 255), (50, 60, 130), "orb"))
    icon(os.path.join(tex, "item", "relic_ember.png"), gem((255, 160, 50), (120, 40, 10), "orb"))
    icon(os.path.join(tex, "item", "relic_veil.png"), gem((80, 200, 240), (20, 70, 120), "shard"))
    icon(os.path.join(tex, "item", "relic_tide.png"), gem((190, 110, 255), (70, 30, 120), "diamond"))

    # block models + item definitions
    for bid, kind in BLOCKS:
        if kind == "all":
            m = {"parent": "minecraft:block/cube_all", "textures": {"all": f"vyrnth:block/{bid}"}}
        else:
            side = f"vyrnth:block/{bid}_side"
            end = f"vyrnth:block/{'gilded_pillar_end' if bid == 'gilded_pillar' else 'brazier_top'}"
            m = {"parent": "minecraft:block/cube_column", "textures": {"end": end, "side": side}}
        jwrite(os.path.join(mdl, "block", bid + ".json"), m)
        jwrite(os.path.join(itm, bid + ".json"), {"model": {"type": "minecraft:model", "model": f"vyrnth:block/{bid}"}})

    # flat membrane plane (two-sided, zero thickness)
    jwrite(os.path.join(mdl, "block", "portal_membrane.json"), {
        "textures": {"0": "vyrnth:block/portal_membrane", "particle": "vyrnth:block/portal_membrane"},
        "elements": [{"from": [0, 0, 8], "to": [16, 16, 8], "faces": {
            "north": {"uv": [0, 0, 16, 16], "texture": "#0"},
            "south": {"uv": [0, 0, 16, 16], "texture": "#0"}}}]})
    jwrite(os.path.join(itm, "portal_membrane.json"), {"model": {"type": "minecraft:model", "model": "vyrnth:block/portal_membrane"}})

    for iid in ["ui_pane", "icon_default", "icon_reliquary", "recall_sigil", "relic_ember", "relic_veil", "relic_tide"]:
        jwrite(os.path.join(mdl, "item", iid + ".json"), {"parent": "minecraft:item/generated", "textures": {"layer0": f"vyrnth:item/{iid}"}})
        jwrite(os.path.join(itm, iid + ".json"), {"model": {"type": "minecraft:model", "model": f"vyrnth:item/{iid}"}})

    # note_block blockstate: EVERY state must be listed, otherwise unlisted states render as missing-texture.
    variants = {}
    for ins in INSTRUMENTS:
        for note in range(25):
            for powered in ("false", "true"):
                key = f"instrument={ins},note={note},powered={powered}"
                model = "minecraft:block/note_block"
                if ins == "harp" and powered == "false" and 1 <= note <= len(BLOCKS):
                    model = f"vyrnth:block/{BLOCKS[note - 1][0]}"
                variants[key] = {"model": model}
    jwrite(os.path.join(root, "assets/minecraft/blockstates/note_block.json"), {"variants": variants})

    with open(os.path.join(root, "README.txt"), "w") as f:
        f.write("VYRNTH resource pack (generated). Custom blocks are note-block states harp/note 1..%d.\n" % len(BLOCKS))

    print("blocks:", len(BLOCKS), "| note_block variants:", len(variants))
    if MAKE_ZIP:
        zp = root.rstrip("/") + ".zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for d, _, files in os.walk(root):
                for fn in files:
                    full = os.path.join(d, fn)
                    z.write(full, os.path.relpath(full, root))
        print("zip:", zp)

def tile_px(rows, x, y):
    px = rows[y][x]
    return px[:3]

if __name__ == "__main__":
    main()
