package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;

public final class VyrnthPlugin extends JavaPlugin {
    private YamlConfiguration data;
    private File dataFile;
    private PlayerStore store;
    private AccessService access;
    private PortalManager portals;
    private DungeonManager dungeons;
    private RelicManager relics;
    private EventManager events;
    private MythicBridge mythic;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveIfMissing("relics.yml");
        saveIfMissing("dungeons/reliquary.yml");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        if (Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) {
            try {
                mythic = new MythicBridge();
                getLogger().info("MythicMobs detected: bosses and mobs will use your Mythic definitions.");
            } catch (Throwable t) {
                mythic = null;
                getLogger().warning("MythicMobs is present but its API could not be used (" + t + "). Using vanilla fallback mobs.");
            }
        } else {
            getLogger().info("MythicMobs not found: using vanilla fallback mobs.");
        }

        store = new PlayerStore(this);
        access = new AccessService(this);
        portals = new PortalManager(this);
        dungeons = new DungeonManager(this);
        relics = new RelicManager(this);
        events = new EventManager(this);

        PluginCommand cmd = getCommand("vyrnth");
        if (cmd == null) throw new IllegalStateException("plugin.yml is missing the vyrnth command");
        AdminCommand admin = new AdminCommand(this);
        cmd.setExecutor(admin);
        cmd.setTabCompleter(admin);

        Bukkit.getPluginManager().registerEvents(new Guards(this), this);
        Bukkit.getPluginManager().registerEvents(new Triggers(this), this);

        checkPaperNoteBlockSetting();

        // Worlds from other plugins (Multiverse etc.) may still be loading during onEnable.
        Bukkit.getScheduler().runTaskLater(this, () -> {
            dungeons.loadAll();
            portals.load();
            portals.startFx();
            relics.start();
        }, 40L);
    }

    @Override
    public void onDisable() {
        if (access != null) access.shutdown();
        if (dungeons != null) dungeons.shutdown();
        if (portals != null) portals.shutdown();
        if (relics != null) relics.stop();
        if (events != null) events.stop(false);
        saveData();
    }

    private void saveIfMissing(String path) {
        if (!new File(getDataFolder(), path).exists()) saveResource(path, false);
    }

    /** Custom blocks are note-block states; Paper must not recompute them on neighbour updates. */
    private void checkPaperNoteBlockSetting() {
        File f = new File(Bukkit.getWorldContainer(), "config/paper-global.yml");
        if (!f.exists()) return;
        boolean off = YamlConfiguration.loadConfiguration(f).getBoolean("block-updates.disable-noteblock-updates", false);
        if (!off) {
            getLogger().warning("============================================================");
            getLogger().warning("config/paper-global.yml -> block-updates.disable-noteblock-updates");
            getLogger().warning("is FALSE. Set it to TRUE and restart, otherwise VYRNTH custom");
            getLogger().warning("blocks placed on vanilla blocks (the lobby gateway) can change look.");
            getLogger().warning("============================================================");
        }
    }

    public YamlConfiguration data() { return data; }

    public void saveData() {
        if (data == null) return;
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Could not save data.yml: " + e.getMessage());
        }
    }

    public PlayerStore store() { return store; }
    public AccessService access() { return access; }
    public PortalManager portals() { return portals; }
    public DungeonManager dungeons() { return dungeons; }
    public RelicManager relics() { return relics; }
    public EventManager events() { return events; }
    /** Null when MythicMobs is not installed. */
    public MythicBridge mythic() { return mythic; }
}
