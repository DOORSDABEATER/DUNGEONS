package net.vyrnth.dungeons;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Runtime of one dungeon (one shared world): chamber waves, ritual seals, the boss fight and the idle reset.
 * All of this runs on the main thread from a 10-tick timer.
 */
public final class Instance {
    private enum State { IDLE, ACTIVE, CLEARED }

    private static final class Chamber {
        final Layout.Room room;
        State state = State.IDLE;
        int wave, emptyTicks;
        long emptySince;
        final Set<UUID> alive = new HashSet<>();

        Chamber(Layout.Room room) { this.room = room; }
    }

    private static final int WAVES = 2;
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"};

    private final VyrnthPlugin pl;
    private final DungeonDef def;
    private final Random rng = new Random();
    private final List<Chamber> chambers = new ArrayList<>();
    private final Set<UUID> barViewers = new HashSet<>();
    private final Set<Integer> fired = new HashSet<>();
    private Layout layout;
    private World world;
    private BukkitTask task;
    private int idleTicks;
    private boolean dirty;
    private UUID bossId;
    private BossBar bar;
    private int bossEmptyTicks;
    private boolean bossDefeated;
    private long bossStart, bossRetryAt;

    public Instance(VyrnthPlugin pl, DungeonDef def) {
        this.pl = pl;
        this.def = def;
    }

    public void attach(World w) {
        this.world = w;
        this.layout = new Layout(def);
        chambers.clear();
        for (int i = 1; i < layout.rooms.size(); i++) chambers.add(new Chamber(layout.room(i)));
    }

    public boolean ready() {
        return world != null && layout != null && pl.dungeons().isBuilt(def.id());
    }

    public void start() {
        stop();
        task = Bukkit.getScheduler().runTaskTimer(pl, this::tick, 20L, 10L);
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
    }

    public World world() { return world; }
    public Layout layout() { return layout; }

    public Location entrance() {
        Vector v = layout.room(0).entry;
        return new Location(world, v.getX(), v.getY(), v.getZ(), -90f, 0f);
    }

    public Location checkpoint(int stage) {
        int idx = Math.max(1, Math.min(stage, layout.chambers));
        Vector v = layout.room(idx).entry;
        return new Location(world, v.getX(), v.getY(), v.getZ(), -90f, 0f);
    }

    // ------------------------------------------------------------------ main loop

    private void tick() {
        if (world == null || layout == null) return;
        List<Player> inside = pl.access().playersIn(def.id());
        if (inside.isEmpty()) {
            if (dirty) {
                idleTicks += 10;
                if (idleTicks >= pl.getConfig().getInt("dungeon.idle-reset-seconds", 90) * 20) resetAll();
            }
            return;
        }
        idleTicks = 0;
        long now = System.currentTimeMillis();
        for (Chamber c : chambers) tickChamber(c, inside, now);
        tickBoss(inside, now);
    }

    private void tickChamber(Chamber c, List<Player> inside, long now) {
        List<Player> here = new ArrayList<>();
        for (Player p : inside) if (c.room.interior.contains(p.getLocation().toVector())) here.add(p);
        for (Player p : here) pl.store().raiseStage(p.getUniqueId(), def.id(), c.room.index);

        switch (c.state) {
            case IDLE -> {
                if (here.isEmpty()) return;
                c.state = State.ACTIVE;
                c.wave = 0;
                c.emptySince = 0;
                c.emptyTicks = 0;
                dirty = true;
                title(here, "<gradient:#7a5cff:#2de2e6>Chamber " + ROMAN[Math.min(c.room.index, 12)], "<gray>The dead stir...");
                for (Player p : here) p.playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.5f, 0.5f);
            }
            case ACTIVE -> {
                c.alive.removeIf(this::gone);
                c.emptyTicks = here.isEmpty() ? c.emptyTicks + 10 : 0;
                if (c.emptyTicks >= 300) { // everyone left: forget this wave
                    despawn(c);
                    c.state = State.IDLE;
                    return;
                }
                if (!c.alive.isEmpty()) { c.emptySince = 0; return; }
                if (c.emptySince == 0) { c.emptySince = now; return; }
                if (now - c.emptySince < 2500 || here.isEmpty()) return;
                c.emptySince = 0;
                if (c.wave < WAVES) spawnWave(c, here); else clear(c, here);
            }
            case CLEARED -> { }
        }
    }

    private void spawnWave(Chamber c, List<Player> here) {
        c.wave++;
        int count = (int) Math.round((3 + 2.0 * c.room.index + def.difficulty())
                * (1 + 0.35 * (here.size() - 1)) * pl.events().mobMult());
        count = Math.max(3, Math.min(40, count));
        List<DungeonDef.Mob> pool = def.mobs();
        List<Vector> pts = c.room.spawns;
        if (pts.isEmpty()) return;
        int tier = c.room.index + def.difficulty();
        for (int i = 0; i < count; i++) {
            Vector v = pts.get(rng.nextInt(pts.size()));
            Location loc = new Location(world, v.getX(), v.getY(), v.getZ());
            Entity e = spawnMob(pick(pool), loc, tier, here.get(rng.nextInt(here.size())));
            if (e != null) c.alive.add(e.getUniqueId());
        }
        for (Player p : here) {
            p.sendActionBar(Msg.mm("<gray>Wave <white>" + c.wave + "/" + WAVES + "</white> — <red>" + c.alive.size() + "</red> bound souls"));
            p.playSound(p.getLocation(), Sound.ENTITY_WARDEN_NEARBY_CLOSE, 0.6f, 0.7f);
        }
    }

    private void clear(Chamber c, List<Player> here) {
        c.state = State.CLEARED;
        setBlocks(c.room.seal, Layout.air());
        Location sc = center(c.room.seal);
        world.playSound(sc, Sound.BLOCK_END_PORTAL_SPAWN, 1f, 1.4f);
        world.spawnParticle(Particle.END_ROD, sc, 60, 0.6, 1.2, 0.6, 0.05);
        title(here, "<green>Chamber cleansed", "<gray>The seal dissolves...");
    }

    private void despawn(Chamber c) {
        for (UUID id : c.alive) {
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
        c.alive.clear();
    }

    // ------------------------------------------------------------------ mobs

    private DungeonDef.Mob pick(List<DungeonDef.Mob> pool) {
        int total = 0;
        for (DungeonDef.Mob m : pool) total += m.weight();
        int r = rng.nextInt(Math.max(1, total));
        for (DungeonDef.Mob m : pool) {
            r -= m.weight();
            if (r < 0) return m;
        }
        return pool.get(0);
    }

    private Entity spawnMob(DungeonDef.Mob m, Location loc, int tier, Player target) {
        Entity e = null;
        MythicBridge mb = pl.mythic();
        if (mb != null) {
            try { e = mb.spawn(m.mythic(), loc); }
            catch (Throwable t) { pl.getLogger().warning("MythicMobs spawn failed for '" + m.mythic() + "': " + t.getMessage()); }
        }
        if (e == null) {
            try { e = world.spawnEntity(loc, m.fallback()); }
            catch (Exception ex) { return null; }
            if (e instanceof LivingEntity le) {
                scale(le, tier);
                le.customName(Msg.item("<dark_aqua>Hollow " + pretty(m.fallback().name())));
                le.setCustomNameVisible(false);
            }
        }
        e.getPersistentDataContainer().set(Keys.MOB, PersistentDataType.BYTE, (byte) 1);
        if (e instanceof LivingEntity le) le.setRemoveWhenFarAway(false);
        if (e instanceof Mob mob && target != null) mob.setTarget(target);
        world.spawnParticle(Particle.SOUL, loc.clone().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.02);
        return e;
    }

    private void scale(LivingEntity le, int tier) {
        AttributeInstance hp = le.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null) {
            hp.setBaseValue(hp.getBaseValue() + 6.0 * tier);
            le.setHealth(hp.getBaseValue());
        }
        AttributeInstance dmg = le.getAttribute(Attribute.ATTACK_DAMAGE);
        if (dmg != null) dmg.setBaseValue(dmg.getBaseValue() + 0.5 * tier);
    }

    private static String pretty(String s) {
        String[] parts = s.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
        return sb.toString().trim();
    }

    private boolean gone(UUID id) {
        Entity e = Bukkit.getEntity(id);
        return e == null || e.isDead() || !e.isValid();
    }

    // ------------------------------------------------------------------ boss

    private List<Player> inArena(List<Player> inside) {
        List<Player> out = new ArrayList<>();
        for (Player p : inside) if (layout.arenaBox.contains(p.getLocation().toVector())) out.add(p);
        return out;
    }

    private void tickBoss(List<Player> inside, long now) {
        List<Player> here = inArena(inside);
        for (Player p : here) pl.store().raiseStage(p.getUniqueId(), def.id(), layout.chambers + 1);

        if (bossId == null) {
            if (!bossDefeated && !here.isEmpty() && now >= bossRetryAt) startBoss(here, now);
            return;
        }
        Entity b = Bukkit.getEntity(bossId);
        if (!(b instanceof LivingEntity le) || !le.isValid()) { // vanished without dying (dead => EntityDeathEvent handles it)
            if (b == null || !b.isDead()) resetBoss(true);
            return;
        }
        for (Player p : inside) {
            boolean in = here.contains(p);
            if (in && barViewers.add(p.getUniqueId())) p.showBossBar(bar);
            else if (!in && barViewers.remove(p.getUniqueId())) p.hideBossBar(bar);
        }
        AttributeInstance max = le.getAttribute(Attribute.MAX_HEALTH);
        double pct = max == null ? 1 : Math.max(0, Math.min(1, le.getHealth() / max.getValue()));
        bar.progress((float) pct);
        for (Map.Entry<Integer, String> ph : def.bossPhases().entrySet()) {
            if (pct * 100 <= ph.getKey() && fired.add(ph.getKey())) firePhase(le, ph.getValue(), here);
        }
        bossEmptyTicks = here.isEmpty() ? bossEmptyTicks + 10 : 0;
        if (bossEmptyTicks >= 300) resetBoss(true);
    }

    private void startBoss(List<Player> here, long now) {
        Entity e = spawnBoss(new Location(world, layout.arenaCenter.getX(), layout.arenaCenter.getY(), layout.arenaCenter.getZ()), here.size());
        if (e == null) {
            pl.getLogger().warning("Boss failed to spawn for dungeon " + def.id());
            bossRetryAt = now + 30_000;
            return;
        }
        dirty = true;
        fired.clear();
        bossStart = now;
        bossEmptyTicks = 0;
        bossId = e.getUniqueId();
        setBlocks(layout.arenaSeal, CBlock.RITUAL_SEAL.data());
        world.playSound(center(layout.arenaSeal), Sound.BLOCK_END_PORTAL_SPAWN, 1f, 0.6f);
        bar = BossBar.bossBar(Msg.mm(def.bossName()), 1f, BossBar.Color.PURPLE, BossBar.Overlay.NOTCHED_10);
        barViewers.clear();
        title(here, def.bossName(), "<gray>The seal closes behind you.");
        for (Player p : here) p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 0.6f);
    }

    private Entity spawnBoss(Location loc, int players) {
        Entity e = null;
        MythicBridge mb = pl.mythic();
        if (mb != null) {
            try { e = mb.spawn(def.bossMythic(), loc); }
            catch (Throwable t) { pl.getLogger().warning("MythicMobs boss spawn failed: " + t.getMessage()); }
        }
        if (e == null) {
            try { e = world.spawnEntity(loc, def.bossFallback()); }
            catch (Exception ex) { return null; }
            if (e instanceof LivingEntity le) {
                double hp = Math.min(1000, def.bossFallbackHealth() * (1 + 0.4 * Math.max(0, players - 1)));
                AttributeInstance a = le.getAttribute(Attribute.MAX_HEALTH);
                if (a != null) { a.setBaseValue(hp); le.setHealth(hp); }
                AttributeInstance d = le.getAttribute(Attribute.ATTACK_DAMAGE);
                if (d != null) d.setBaseValue(12 + 2 * def.difficulty());
                AttributeInstance k = le.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
                if (k != null) k.setBaseValue(1.0);
                le.customName(Msg.item(def.bossName()));
                le.setCustomNameVisible(true);
                EntityEquipment eq = le.getEquipment();
                if (eq != null) {
                    eq.setItemInMainHand(new ItemStack(Material.NETHERITE_SWORD));
                    eq.setItemInMainHandDropChance(0f);
                }
            }
        }
        e.getPersistentDataContainer().set(Keys.MOB, PersistentDataType.BYTE, (byte) 1);
        if (e instanceof LivingEntity le) le.setRemoveWhenFarAway(false);
        return e;
    }

    private void firePhase(LivingEntity boss, String skill, List<Player> here) {
        title(here, def.bossName(), "<gray>The ritual quickens...");
        world.playSound(boss.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6f, 0.5f);
        boolean ok = false;
        MythicBridge mb = pl.mythic();
        if (mb != null && skill != null && !skill.isBlank()) {
            try { ok = mb.cast(boss, skill); } catch (Throwable t) { ok = false; }
        }
        if (!ok) { // no MythicMobs (or skill missing): summon minions the plain way
            List<DungeonDef.Mob> pool = def.mobs();
            for (int i = 0; i < 3 + def.difficulty(); i++) {
                double ang = rng.nextDouble() * Math.PI * 2;
                Location l = boss.getLocation().add(Math.cos(ang) * 5, 0, Math.sin(ang) * 5);
                Entity e = spawnMob(pick(pool), l, def.difficulty(), here.isEmpty() ? null : here.get(rng.nextInt(here.size())));
                if (e != null && !chambers.isEmpty()) chambers.get(chambers.size() - 1).alive.add(e.getUniqueId());
            }
        }
    }

    /** Called from the entity-death listener. */
    public void onEntityDeath(Entity e) {
        if (bossId != null && e.getUniqueId().equals(bossId)) victory();
    }

    private void victory() {
        List<Player> here = inArena(pl.access().playersIn(def.id()));
        bossId = null;
        bossDefeated = true;
        hideBar();
        setBlocks(layout.arenaSeal, Layout.air());
        long secs = Math.max(1, (System.currentTimeMillis() - bossStart) / 1000);
        double mult = pl.events().rewardMult();
        List<UUID> ids = new ArrayList<>();
        for (Player p : here) {
            ids.add(p.getUniqueId());
            pl.store().recordClear(p.getUniqueId(), def.id(), secs);
            giveRewards(p, mult);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        title(here, "<gradient:#ffd36b:#ff9f43>THE KING IS FELLED", "<gray>Cleared in <white>" + secs + "s");
        int wait = pl.getConfig().getInt("dungeon.victory-return-seconds", 20);
        new BukkitRunnable() {
            int left = wait;

            @Override
            public void run() {
                left--;
                for (UUID id : ids) {
                    Player p = Bukkit.getPlayer(id);
                    if (p == null || !pl.access().hasSession(p)) continue;
                    if (left <= 0) pl.access().returnToLobby(p, "victory");
                    else p.sendActionBar(Msg.mm("<gray>The gateway reopens in <white>" + left + "s"));
                }
                if (left <= 0) cancel();
            }
        }.runTaskTimer(pl, 20L, 20L);
    }

    private void giveRewards(Player p, double mult) {
        int xp = (int) Math.round(def.rewardXp() * mult);
        if (xp > 0) p.giveExp(xp);
        for (ItemStack it : def.rewardItems()) {
            ItemStack c = it.clone();
            c.setAmount(Math.max(1, Math.min(c.getMaxStackSize(), (int) Math.round(c.getAmount() * mult))));
            give(p, c);
        }
        for (Map.Entry<String, Double> e : def.relicDrops().entrySet()) {
            if (rng.nextDouble() >= e.getValue()) continue;
            ItemStack relic = pl.relics().item(e.getKey(), 1);
            if (relic == null) continue;
            give(p, relic);
            p.sendMessage(Msg.mm(Msg.PREFIX + "<gray>A relic answers your victory: ").append(relic.getItemMeta().displayName()));
        }
        for (String cmd : def.rewardCommands()) {
            String c = cmd.startsWith("/") ? cmd.substring(1) : cmd;
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
        }
    }

    private static void give(Player p, ItemStack it) {
        p.getInventory().addItem(it).values().forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
    }

    private void resetBoss(boolean announce) {
        Entity b = bossId == null ? null : Bukkit.getEntity(bossId);
        if (b != null) b.remove();
        bossId = null;
        hideBar();
        setBlocks(layout.arenaSeal, Layout.air());
        fired.clear();
        if (announce) {
            for (Player p : inArena(pl.access().playersIn(def.id())))
                p.sendMessage(Msg.mm(Msg.PREFIX + "<gray>The king sinks back into slumber."));
        }
    }

    private void hideBar() {
        if (bar != null) {
            for (UUID id : barViewers) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.hideBossBar(bar);
            }
        }
        barViewers.clear();
        bar = null;
    }

    public void onLeave(Player p) {
        if (bar != null && barViewers.remove(p.getUniqueId())) p.hideBossBar(bar);
    }

    // ------------------------------------------------------------------ admin hooks

    public String adminSpawnBoss() {
        if (!ready()) return "Dungeon is not built.";
        if (bossId != null) return "A boss is already active.";
        bossDefeated = false;
        bossRetryAt = 0;
        startBoss(inArena(pl.access().playersIn(def.id())), System.currentTimeMillis());
        return bossId == null ? "Boss failed to spawn (see console)." : null;
    }

    public boolean adminKillBoss() {
        if (bossId == null) return false;
        resetBoss(false);
        return true;
    }

    public String status() {
        StringBuilder sb = new StringBuilder();
        sb.append("players=").append(pl.access().playersIn(def.id()).size()).append(" dirty=").append(dirty)
                .append(" boss=").append(bossId != null ? "FIGHTING" : bossDefeated ? "DEFEATED" : "asleep");
        for (Chamber c : chambers)
            sb.append(" | C").append(c.room.index).append('=').append(c.state).append('(').append(c.alive.size()).append(')');
        return sb.toString();
    }

    // ------------------------------------------------------------------ reset

    public void resetAll() {
        if (world == null || layout == null) return;
        for (Chamber c : chambers) {
            despawn(c);
            c.state = State.IDLE;
            c.wave = 0;
            c.emptySince = 0;
            setBlocks(c.room.seal, CBlock.RITUAL_SEAL.data());
        }
        resetBoss(false);
        bossDefeated = false;
        bossRetryAt = 0;
        for (LivingEntity le : world.getEntitiesByClass(LivingEntity.class))
            if (le.getPersistentDataContainer().has(Keys.MOB, PersistentDataType.BYTE)) le.remove();
        dirty = false;
        idleTicks = 0;
    }

    // ------------------------------------------------------------------ helpers

    private void setBlocks(List<int[]> cells, BlockData d) {
        for (int[] c : cells) world.getBlockAt(c[0], c[1], c[2]).setBlockData(d, false);
    }

    private Location center(List<int[]> cells) {
        int[] a = cells.get(0), b = cells.get(cells.size() - 1);
        return new Location(world, (a[0] + b[0]) / 2.0 + 0.5, (a[1] + b[1]) / 2.0 + 0.5, (a[2] + b[2]) / 2.0 + 0.5);
    }

    private void title(List<Player> to, String main, String sub) {
        Title t = Title.title(Msg.mm(main), Msg.mm(sub),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(600)));
        for (Player p : to) p.showTitle(t);
    }
}
