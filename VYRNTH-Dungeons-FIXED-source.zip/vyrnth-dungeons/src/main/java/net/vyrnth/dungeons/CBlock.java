package net.vyrnth.dungeons;

import org.bukkit.Instrument;
import org.bukkit.Material;
import org.bukkit.Note;
import org.bukkit.NamespacedKey;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;

/**
 * VYRNTH custom blocks. Each one is a unique note-block state (instrument=harp, note=ordinal+1) that the
 * resource pack remaps to a custom model/texture. ORDER MATTERS: it must match BLOCKS in
 * resourcepack/generate_pack.py (note = index+1). Only append new entries at the end (max 24).
 * Note 0 is left untouched so a vanilla note block never looks custom.
 */
public enum CBlock {
    RUIN_BRICK("ruin_brick", "Ruin Brick"),
    CARVED_RUNESTONE("carved_runestone", "Carved Runestone"),
    FLAGSTONE("flagstone", "Cracked Flagstone"),
    SIGIL_FLOOR("sigil_floor", "Sigil Floor"),
    GILDED_PILLAR("gilded_pillar", "Gilded Pillar"),
    ANCIENT_GOLD("ancient_gold", "Ancient Gold Plate"),
    OVERGROWN_RUIN("overgrown_ruin", "Overgrown Ruin"),
    BONE_MORTAR("bone_mortar", "Bone Mortar"),
    RITUAL_SEAL("ritual_seal", "Ritual Seal"),
    GATEWAY_STONE("gateway_stone", "Gateway Stone"),
    GATEWAY_GLYPH("gateway_glyph", "Gateway Glyph"),
    VOID_OBSIDIAN("void_obsidian", "Void Obsidian"),
    BRAZIER("brazier", "Soul Brazier"),
    ECLIPSE_TILE("eclipse_tile", "Eclipse Tile");

    private static final Map<String, CBlock> BY_ID = new HashMap<>();
    private static final CBlock[] ALL = values();

    static {
        if (ALL.length > 24) throw new IllegalStateException("Too many custom blocks for the harp note range");
        for (CBlock b : ALL) BY_ID.put(b.id, b);
    }

    public final String id;
    public final String display;
    private BlockData data;

    CBlock(String id, String display) {
        this.id = id;
        this.display = display;
    }

    public BlockData data() {
        if (data == null) {
            NoteBlock nb = (NoteBlock) Material.NOTE_BLOCK.createBlockData();
            nb.setInstrument(Instrument.PIANO);
            nb.setNote(new Note(ordinal() + 1));
            nb.setPowered(false);
            data = nb;
        }
        return data.clone();
    }

    /** Which custom block (if any) does this block data represent? */
    public static CBlock of(BlockData d) {
        if (!(d instanceof NoteBlock nb)) return null;
        if (nb.getInstrument() != Instrument.PIANO || nb.isPowered()) return null;
        int n = nb.getNote().getId();
        if (n < 1 || n > ALL.length) return null;
        return ALL[n - 1];
    }

    public static CBlock byId(String id) {
        return id == null ? null : BY_ID.get(id.toLowerCase());
    }

    public ItemStack item(int amount) {
        ItemStack it = new ItemStack(Material.NOTE_BLOCK, amount);
        ItemMeta m = it.getItemMeta();
        m.displayName(Msg.item("<#9fb6ff>" + display));
        m.setItemModel(new NamespacedKey("vyrnth", id));
        m.getPersistentDataContainer().set(Keys.CBLOCK, PersistentDataType.STRING, id);
        it.setItemMeta(m);
        return it;
    }

    public static CBlock fromItem(ItemStack it) {
        if (it == null || it.getType() != Material.NOTE_BLOCK || !it.hasItemMeta()) return null;
        String id = it.getItemMeta().getPersistentDataContainer().get(Keys.CBLOCK, PersistentDataType.STRING);
        return byId(id);
    }
}
