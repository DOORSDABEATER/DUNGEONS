package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.inventory.EquipmentSlot;

/** Gameplay triggers: gateway walk-in / click, the selection menu, return gate, recall sigil, boss/mob deaths. */
public final class Triggers implements Listener {
    private final VyrnthPlugin pl;

    public Triggers(VyrnthPlugin pl) {
        this.pl = pl;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedBlock() || e.getTo() == null) return;
        Player p = e.getPlayer();
        PortalManager.Rec r = pl.portals().at(e.getTo());
        if (r == null) return;
        if (r.kind == PortalManager.Kind.RETURN) {
            if (pl.access().hasSession(p)) pl.access().returnToLobby(p, "gate");
        } else {
            pl.access().openPortal(p, r);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        Action a = e.getAction();
        if (a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null) {
            PortalManager.Rec r = pl.portals().structureAt(e.getClickedBlock());
            if (r != null && r.kind == PortalManager.Kind.LOBBY) {
                e.setCancelled(true);
                pl.access().openPortal(p, r);
                return;
            }
        }
        if ((a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK) && Items.isSigil(e.getItem())) {
            e.setCancelled(true);
            pl.access().startRecall(p);
        }
    }

    // ------------------------------------------------------------------ menu

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof PortalMenu menu)) return;
        e.setCancelled(true); // nothing can be taken from / put into the menu, incl. shift-click
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        String id = menu.dungeonAt(e.getSlot());
        if (id == null) return;
        ClickType ct = e.getClick();
        boolean resume = ct.isRightClick();
        Bukkit.getScheduler().runTask(pl, () -> {
            p.closeInventory();
            DungeonDef d = pl.dungeons().def(id);
            if (d == null) return;
            String err = pl.access().enter(p, d, resume, false); // full server-side validation happens here
            if (err != null) Msg.err(p, err);
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof PortalMenu) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ sigil / recall

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (Items.isSigil(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && pl.access().isRecalling(p)) {
            pl.access().cancelRecall(p.getUniqueId());
            p.sendActionBar(Msg.mm("<red>Recall broken."));
        }
    }

    // ------------------------------------------------------------------ mobs / bosses

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        pl.dungeons().onEntityDeath(e);
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent e) {
        pl.portals().load(); // idempotent: registers gateways whose world just became available
    }
}
