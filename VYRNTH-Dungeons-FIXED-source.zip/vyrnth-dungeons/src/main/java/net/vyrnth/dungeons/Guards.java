package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.NotePlayEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.List;
import java.util.Locale;

/**
 * Security layer. Everything here is enforced server-side at event time; nothing relies on hiding commands
 * from tab-completion.
 */
public final class Guards implements Listener {
    private final VyrnthPlugin pl;

    public Guards(VyrnthPlugin pl) {
        this.pl = pl;
    }

    private boolean inDungeonWorld(Player p) {
        return pl.dungeons().isDungeonWorld(p.getWorld().getName());
    }

    // ================================================================== commands

    /** Defense in depth: even if the command executor were bypassed, non-OPs never reach a VYRNTH command. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        String msg = e.getMessage();
        if (msg.length() < 2) return;
        String label = msg.substring(1).trim().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        if (label.isEmpty()) return;

        Command c = Bukkit.getCommandMap().getCommand(label);
        if (c instanceof PluginCommand pc && pc.getPlugin() == pl && !Access.isAdmin(p)) {
            e.setCancelled(true);
            Msg.err(p, "The ancient seals do not answer to you. <dark_gray>(OP only)");
            return;
        }
        if (Access.isAdmin(p)) return;
        if (pl.access().hasSession(p) || inDungeonWorld(p)) {
            String bare = label.contains(":") ? label.substring(label.indexOf(':') + 1) : label;
            List<String> allowed = pl.getConfig().getStringList("dungeon.allowed-commands");
            if (!allowed.contains(bare)) {
                e.setCancelled(true);
                p.sendActionBar(Msg.mm("<red>The dungeon swallows your words. Use your Recall Sigil to leave."));
            }
        }
    }

    /** Cosmetic only (the check above is the real one): hide the command from non-OP clients. */
    @EventHandler
    public void onCommandSend(PlayerCommandSendEvent e) {
        if (Access.isAdmin(e.getPlayer())) return;
        e.getCommands().removeIf(n -> n.equals("vyrnth") || n.endsWith(":vyrnth"));
    }

    // ================================================================== teleport validation

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTeleport(PlayerTeleportEvent e) {
        Location to = e.getTo();
        if (to == null || to.getWorld() == null) return;
        if (!pl.dungeons().isDungeonWorld(to.getWorld().getName())) return;
        Player p = e.getPlayer();
        if (Access.isAdmin(p) || pl.access().hasToken(p)) return;
        e.setCancelled(true); // includes ender pearls / chorus fruit / other plugins inside dungeons
        pl.getLogger().fine("Blocked unauthorized teleport of " + p.getName() + " into " + to.getWorld().getName());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortal(PlayerPortalEvent e) {
        Player p = e.getPlayer();
        if (Access.isAdmin(p)) return;
        Location to = e.getTo();
        boolean toDungeon = to != null && to.getWorld() != null && pl.dungeons().isDungeonWorld(to.getWorld().getName());
        if (toDungeon || pl.access().hasSession(p)) e.setCancelled(true);
    }

    /** Last-resort net: a non-admin who somehow ends up in a dungeon world without a session is sent home. */
    @EventHandler
    public void onChangedWorld(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        if (Access.isAdmin(p) || pl.access().hasSession(p)) return;
        if (inDungeonWorld(p)) Bukkit.getScheduler().runTask(pl, () -> pl.access().returnToLobby(p, "quiet"));
    }

    // ================================================================== lifecycle / recovery

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (p.isOnline()) pl.access().recoverOnJoin(p);
        }, 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        pl.access().onQuit(e.getPlayer());
        pl.store().unload(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent e) {
        pl.access().onRespawn(e.getPlayer(), e);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(Items::isSigil);
    }

    // ================================================================== world protection

    private boolean protectedBlock(org.bukkit.block.Block b, Player p) {
        if (p != null && Access.isAdmin(p)) return false;
        return pl.dungeons().isDungeonWorld(b.getWorld().getName()) || pl.portals().structureAt(b) != null;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (protectedBlock(e.getBlock(), e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (protectedBlock(e.getBlock(), e.getPlayer())) e.setCancelled(true);
        else if (CBlock.fromItem(e.getItemInHand()) != null && !Access.isAdmin(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (protectedBlock(e.getBlock(), e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (protectedBlock(e.getBlock(), e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> protectedBlock(b, null));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> protectedBlock(b, null));
    }

    // ================================================================== custom block handling

    /** Items made by /vyrnth block give become their custom block state when an admin places them. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlaceCustom(BlockPlaceEvent e) {
        CBlock cb = CBlock.fromItem(e.getItemInHand());
        if (cb == null || !Access.isAdmin(e.getPlayer())) return;
        e.getBlockPlaced().setBlockData(cb.data(), false);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreakCustom(BlockBreakEvent e) {
        CBlock cb = CBlock.of(e.getBlock().getBlockData());
        if (cb == null) return;
        e.setDropItems(false);
        if (e.getPlayer().getGameMode() != GameMode.CREATIVE)
            e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation().add(0.5, 0.5, 0.5), cb.item(1));
    }

    /** Vanilla note-block tuning is disabled: it would let players cycle blocks into custom states. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onNoteTune(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() != Material.NOTE_BLOCK) return;
        boolean custom = CBlock.of(e.getClickedBlock().getBlockData()) != null;
        if (custom || !Access.isAdmin(e.getPlayer())) e.setUseInteractedBlock(Event.Result.DENY);
    }

    @EventHandler(ignoreCancelled = true)
    public void onNotePlay(NotePlayEvent e) {
        if (CBlock.of(e.getBlock().getBlockData()) != null) e.setCancelled(true);
    }
}
