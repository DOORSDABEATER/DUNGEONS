package net.vyrnth.dungeons;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;

public final class Msg {
    private Msg() {}
    private static final MiniMessage MM = MiniMessage.miniMessage();
    public static final String PREFIX = "<gradient:#7a5cff:#2de2e6><bold>VYRNTH</bold></gradient> <dark_gray>»</dark_gray> ";

    public static Component mm(String s) {
        return MM.deserialize(s);
    }

    /** For item names / lore: MiniMessage without the default italic. */
    public static Component item(String s) {
        return MM.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public static void send(CommandSender to, String s) {
        to.sendMessage(mm(PREFIX + "<gray>" + s));
    }

    public static void err(CommandSender to, String s) {
        to.sendMessage(mm(PREFIX + "<red>" + s));
    }
}
