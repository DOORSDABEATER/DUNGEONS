package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** The dungeon-selection interface shown by the lobby gateway. Clicks are handled in Triggers. */
public final class PortalMenu implements InventoryHolder {
    private final Inventory inv;
    private final Map<Integer, String> slots = new HashMap<>();

    public PortalMenu(VyrnthPlugin pl, Player p) {
        List<DungeonDef> list = pl.dungeons().enabledDefs();
        int size = list.size() <= 9 ? 27 : 54;
        inv = Bukkit.createInventory(this, size, Msg.mm("<gradient:#7a5cff:#2de2e6>VYRNTH</gradient> <dark_gray>— <gray>Choose your descent"));
        ItemStack pane = Items.pane();
        for (int i = 0; i < size; i++) inv.setItem(i, pane);
        int n = Math.min(list.size(), size);
        int start = size == 27 ? 9 + (9 - n) / 2 : 0;
        for (int i = 0; i < n; i++) {
            DungeonDef d = list.get(i);
            inv.setItem(start + i, icon(pl, p, d));
            slots.put(start + i, d.id());
        }
    }

    private ItemStack icon(VyrnthPlugin pl, Player p, DungeonDef d) {
        int stage = pl.store().stage(p.getUniqueId(), d.id());
        int total = d.chambers() + 1;
        List<String> lore = new ArrayList<>(d.description());
        lore.add("");
        lore.add("<gray>Chambers: <white>" + d.chambers() + "</white>  <gray>Danger: <red>" + "☠".repeat(Math.max(1, d.difficulty())));
        lore.add("<gray>Progress: <white>" + Math.min(stage, total) + "/" + total
                + "</white>  <gray>Kings felled: <white>" + pl.store().bosses(p.getUniqueId(), d.id()));
        EventManager.Ev ev = pl.events().active();
        if (ev != null) lore.add("<gray>Active rite: " + ev.display());
        lore.add("");
        lore.add("<yellow>Left-click <gray>» descend from the entrance");
        if (stage > 0) lore.add("<yellow>Right-click <gray>» resume at chamber <white>" + Math.min(stage, d.chambers()));
        return Items.skinned(Material.ECHO_SHARD, d.iconModel(), d.display(), lore);
    }

    public String dungeonAt(int slot) {
        return slots.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
