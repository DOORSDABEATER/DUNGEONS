package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * /vyrnth ... : the ONLY command in the plugin. Every subcommand handler re-checks Access.require() itself,
 * so adding a new branch can never accidentally ship an unguarded path.
 */
public final class AdminCommand implements CommandExecutor, TabCompleter {
    private final VyrnthPlugin pl;

    public AdminCommand(VyrnthPlugin pl) {
        this.pl = pl;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!Access.require(s)) return true;
        if (a.length == 0) { help(s); return true; }
        try {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "help" -> help(s);
                case "reload" -> reload(s);
                case "lobby" -> lobby(s, a);
                case "portal" -> portal(s, a);
                case "dungeon" -> dungeon(s, a);
                case "boss" -> boss(s, a);
                case "reward" -> reward(s, a);
                case "relic" -> relic(s, a);
                case "progress" -> progress(s, a);
                case "event" -> event(s, a);
                case "player" -> playerCmd(s, a);
                case "block" -> block(s, a);
                case "debug" -> debug(s, a);
                default -> Msg.err(s, "Unknown subcommand. Try /vyrnth help");
            }
        } catch (IllegalArgumentException ex) {
            Msg.err(s, ex.getMessage());
        } catch (Exception ex) {
            Msg.err(s, "Internal error, see console.");
            pl.getLogger().log(Level.WARNING, "Admin command failed", ex);
        }
        return true;
    }

    // ------------------------------------------------------------------ helpers

    private static Player self(CommandSender s) {
        if (s instanceof Player p) return p;
        throw new IllegalArgumentException("This subcommand must be run in-game.");
    }

    private static Player online(String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) throw new IllegalArgumentException("Player not online: " + name);
        return p;
    }

    private DungeonDef def(String id) {
        DungeonDef d = pl.dungeons().def(id);
        if (d == null) throw new IllegalArgumentException("Unknown dungeon: " + id);
        return d;
    }

    private static String arg(String[] a, int i, String usage) {
        if (a.length <= i) throw new IllegalArgumentException("Usage: " + usage);
        return a[i];
    }

    private static int num(String s, int min, int max) {
        try {
            int n = Integer.parseInt(s);
            if (n < min || n > max) throw new IllegalArgumentException("Number must be " + min + ".." + max);
            return n;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Not a number: " + s);
        }
    }

    private static OfflinePlayer offline(String name) {
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        if (!op.isOnline() && !op.hasPlayedBefore()) throw new IllegalArgumentException("Unknown player: " + name);
        return op;
    }

    private void help(CommandSender s) {
        if (!Access.require(s)) return;
        String[] lines = {
                "lobby <set|tp>",
                "portal <build [id]|remove <id>|list|refresh>",
                "dungeon <list|info|build|rebuild|enable|disable|reset|tp> <id> [chamber|arena]",
                "boss <spawn|kill> <dungeon>  |  boss summon <mythicId>",
                "reward <list|addcmd|delcmd|additem|delitem|xp|clear> <dungeon> ...",
                "relic <list|give|take> ...",
                "progress <get|set|reset> <player> [dungeon] [stage]",
                "event <start|stop|status|list> ...",
                "player <list|kick|send> ...",
                "block <list|give> <player> <blockId> [n]",
                "debug <session|status|fx> ...",
                "reload"};
        Msg.send(s, "<white>VYRNTH admin</white> <dark_gray>(OP/console only)");
        for (String l : lines) s.sendMessage(Msg.mm("<dark_gray> • <gray>/vyrnth <white>" + l));
    }

    private void reload(CommandSender s) {
        if (!Access.require(s)) return;
        pl.reloadConfig();
        pl.events().load();
        pl.relics().load();
        pl.dungeons().loadAll();
        pl.portals().load();
        pl.portals().refreshAll();
        Msg.send(s, "Reloaded config, relics, dungeons and gateways.");
    }

    // ------------------------------------------------------------------ lobby / portal

    private void lobby(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth lobby <set|tp>").toLowerCase(Locale.ROOT)) {
            case "set" -> {
                Player p = self(s);
                pl.access().setLobby(p.getLocation());
                Msg.send(s, "Main lobby spawn set here. This is where every return/respawn/recovery lands.");
            }
            case "tp" -> self(s).teleport(pl.access().lobby());
            default -> throw new IllegalArgumentException("Usage: /vyrnth lobby <set|tp>");
        }
    }

    private void portal(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth portal <build|remove|list|refresh>").toLowerCase(Locale.ROOT)) {
            case "build" -> {
                Player p = self(s);
                String id = a.length > 2 ? a[2].toLowerCase(Locale.ROOT) : "main";
                if (!id.matches("[a-z0-9_]+")) throw new IllegalArgumentException("Gateway ids: a-z, 0-9, _");
                if (pl.dungeons().isDungeonWorld(p.getWorld().getName()))
                    throw new IllegalArgumentException("Build the lobby gateway in your MAIN LOBBY, not in a dungeon world.");
                String err = pl.portals().buildLobby(id, p);
                if (err != null) throw new IllegalArgumentException(err);
                Msg.send(s, "Gateway <white>" + id + "</white> awakened 5 blocks ahead (11x11x7, floor included). "
                        + "<gray>Undo with /vyrnth portal remove " + id);
            }
            case "remove" -> {
                String err = pl.portals().remove(arg(a, 2, "/vyrnth portal remove <id>").toLowerCase(Locale.ROOT));
                if (err != null) throw new IllegalArgumentException(err);
                Msg.send(s, "Gateway removed and the old blocks restored.");
            }
            case "list" -> {
                if (pl.portals().all().isEmpty()) Msg.send(s, "No gateways yet. Stand in the lobby and run /vyrnth portal build");
                pl.portals().all().values().forEach(r -> Msg.send(s, "<white>" + r.id + "</white> " + r.kind + " @ " + r.world
                        + " " + r.x + "," + r.y + "," + r.z + " facing " + r.facing));
            }
            case "refresh" -> {
                pl.portals().refreshAll();
                Msg.send(s, "Gateway visuals refreshed.");
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth portal <build|remove|list|refresh>");
        }
    }

    // ------------------------------------------------------------------ dungeons

    private void dungeon(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        String sub = arg(a, 1, "/vyrnth dungeon <list|info|build|rebuild|enable|disable|reset|tp>").toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            for (DungeonDef d : pl.dungeons().defs())
                Msg.send(s, "<white>" + d.id() + "</white> world=" + d.worldName() + " enabled=" + d.enabled()
                        + " built=" + pl.dungeons().isBuilt(d.id()) + (pl.dungeons().isBuilding(d.id()) ? " <yellow>(forging)" : ""));
            return;
        }
        DungeonDef d = def(arg(a, 2, "/vyrnth dungeon " + sub + " <id>"));
        Instance inst = pl.dungeons().instance(d.id());
        switch (sub) {
            case "info" -> {
                Msg.send(s, "<white>" + d.id() + "</white> world=" + d.worldName() + " seed=" + d.seed() + " chambers=" + d.chambers()
                        + " difficulty=" + d.difficulty());
                Msg.send(s, "boss=" + d.bossMythic() + " (MythicMobs " + (pl.mythic() != null ? "active" : "not installed -> vanilla fallback") + ")"
                        + " | rewards: xp=" + d.rewardXp() + " cmds=" + d.rewardCommands().size() + " items=" + d.rewardItems().size());
            }
            case "build" -> {
                if (pl.dungeons().isBuilt(d.id())) throw new IllegalArgumentException("Already built. Use /vyrnth dungeon rebuild " + d.id() + " to wipe and redo it.");
                pl.dungeons().build(d, s, false);
            }
            case "rebuild" -> pl.dungeons().build(d, s, true);
            case "enable" -> { d.setEnabled(true); Msg.send(s, d.id() + " enabled."); }
            case "disable" -> { d.setEnabled(false); Msg.send(s, d.id() + " disabled (hidden from the gateway menu)."); }
            case "reset" -> {
                if (inst == null || !inst.ready()) throw new IllegalArgumentException("Dungeon is not built.");
                inst.resetAll();
                Msg.send(s, "Dungeon reset: mobs cleared, seals re-formed, boss re-armed.");
            }
            case "tp" -> {
                Player p = self(s);
                if (inst == null || !inst.ready()) throw new IllegalArgumentException("Dungeon is not built.");
                String where = a.length > 3 ? a[3].toLowerCase(Locale.ROOT) : "entrance";
                Location dest;
                if (where.equals("arena") || where.equals("boss")) {
                    var v = inst.layout().arenaCenter;
                    dest = new Location(inst.world(), v.getX() - 8, v.getY(), v.getZ(), -90f, 0f);
                } else if (where.equals("entrance")) dest = inst.entrance();
                else dest = inst.checkpoint(num(where, 1, d.chambers()));
                p.teleport(dest); // admins are allowed by the teleport guard
            }
            default -> throw new IllegalArgumentException("Unknown dungeon subcommand.");
        }
    }

    // ------------------------------------------------------------------ bosses

    private void boss(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        String sub = arg(a, 1, "/vyrnth boss <spawn|kill|summon>").toLowerCase(Locale.ROOT);
        switch (sub) {
            case "spawn" -> {
                DungeonDef d = def(arg(a, 2, "/vyrnth boss spawn <dungeon>"));
                Instance i = pl.dungeons().instance(d.id());
                if (i == null) throw new IllegalArgumentException("Dungeon not loaded.");
                String err = i.adminSpawnBoss();
                if (err != null) throw new IllegalArgumentException(err);
                Msg.send(s, "The boss of " + d.id() + " awakens.");
            }
            case "kill" -> {
                DungeonDef d = def(arg(a, 2, "/vyrnth boss kill <dungeon>"));
                Instance i = pl.dungeons().instance(d.id());
                Msg.send(s, i != null && i.adminKillBoss() ? "Boss dismissed (no rewards)." : "No active boss.");
            }
            case "summon" -> {
                Player p = self(s);
                String type = arg(a, 2, "/vyrnth boss summon <mythicMobId>");
                if (pl.mythic() == null) throw new IllegalArgumentException("MythicMobs is not installed.");
                Entity e = pl.mythic().spawn(type, p.getLocation());
                if (e == null) throw new IllegalArgumentException("MythicMobs has no mob called '" + type + "'. Did you /mm reload?");
                Msg.send(s, "Summoned <white>" + type + "</white> at your feet.");
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth boss <spawn|kill|summon>");
        }
    }

    // ------------------------------------------------------------------ rewards

    private void reward(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        String sub = arg(a, 1, "/vyrnth reward <list|addcmd|delcmd|additem|delitem|xp|clear> <dungeon>").toLowerCase(Locale.ROOT);
        DungeonDef d = def(arg(a, 2, "/vyrnth reward " + sub + " <dungeon>"));
        switch (sub) {
            case "list" -> {
                Msg.send(s, "<white>" + d.id() + "</white> rewards: xp=" + d.rewardXp());
                List<String> cmds = d.rewardCommands();
                for (int i = 0; i < cmds.size(); i++) s.sendMessage(Msg.mm("<dark_gray> cmd " + (i + 1) + ": <gray>" + cmds.get(i).replace("<", "\\<")));
                List<ItemStack> items = d.rewardItems();
                for (int i = 0; i < items.size(); i++) s.sendMessage(Msg.mm("<dark_gray> item " + (i + 1) + ": <gray>" + items.get(i).getType() + " x" + items.get(i).getAmount()));
                d.relicDrops().forEach((k, v) -> s.sendMessage(Msg.mm("<dark_gray> relic: <gray>" + k + " @ " + (int) (v * 100) + "%")));
            }
            case "addcmd" -> {
                if (a.length < 4) throw new IllegalArgumentException("Usage: /vyrnth reward addcmd <dungeon> <console command with %player%>");
                List<String> cmds = d.rewardCommands();
                cmds.add(String.join(" ", Arrays.copyOfRange(a, 3, a.length)));
                d.setRewardCommands(cmds);
                Msg.send(s, "Reward command added (runs as console on boss kill).");
            }
            case "delcmd" -> {
                List<String> cmds = d.rewardCommands();
                int i = num(arg(a, 3, "/vyrnth reward delcmd <dungeon> <n>"), 1, Math.max(1, cmds.size()));
                if (cmds.isEmpty()) throw new IllegalArgumentException("No commands.");
                cmds.remove(i - 1);
                d.setRewardCommands(cmds);
                Msg.send(s, "Removed.");
            }
            case "additem" -> {
                Player p = self(s);
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) throw new IllegalArgumentException("Hold the reward item in your main hand.");
                List<ItemStack> items = d.rewardItems();
                items.add(hand.clone());
                d.setRewardItems(items);
                Msg.send(s, "Added " + hand.getType() + " x" + hand.getAmount() + " to the reward pool.");
            }
            case "delitem" -> {
                List<ItemStack> items = d.rewardItems();
                if (items.isEmpty()) throw new IllegalArgumentException("No items.");
                int i = num(arg(a, 3, "/vyrnth reward delitem <dungeon> <n>"), 1, items.size());
                items.remove(i - 1);
                d.setRewardItems(items);
                Msg.send(s, "Removed.");
            }
            case "xp" -> {
                d.setRewardXp(num(arg(a, 3, "/vyrnth reward xp <dungeon> <amount>"), 0, 1_000_000));
                Msg.send(s, "XP reward set to " + d.rewardXp() + ".");
            }
            case "clear" -> {
                d.setRewardCommands(new ArrayList<>());
                d.setRewardItems(new ArrayList<>());
                d.setRewardXp(0);
                Msg.send(s, "All rewards cleared for " + d.id() + ".");
            }
            default -> throw new IllegalArgumentException("Unknown reward subcommand.");
        }
    }

    // ------------------------------------------------------------------ relics

    private void relic(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth relic <list|give|take>").toLowerCase(Locale.ROOT)) {
            case "list" -> Msg.send(s, "Relics: <white>" + String.join(", ", pl.relics().ids()));
            case "give" -> {
                Player p = online(arg(a, 2, "/vyrnth relic give <player> <id> [n]"));
                String id = arg(a, 3, "/vyrnth relic give <player> <id> [n]");
                ItemStack it = pl.relics().item(id, a.length > 4 ? num(a[4], 1, 64) : 1);
                if (it == null) throw new IllegalArgumentException("Unknown relic: " + id);
                p.getInventory().addItem(it).values().forEach(l -> p.getWorld().dropItemNaturally(p.getLocation(), l));
                Msg.send(s, "Gave " + id + " to " + p.getName() + ".");
            }
            case "take" -> {
                Player p = online(arg(a, 2, "/vyrnth relic take <player> <id> [n]"));
                String id = arg(a, 3, "/vyrnth relic take <player> <id> [n]");
                int n = pl.relics().take(p, id, a.length > 4 ? num(a[4], 1, 2304) : 1);
                Msg.send(s, "Removed " + n + " relic(s) from " + p.getName() + ".");
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth relic <list|give|take>");
        }
    }

    // ------------------------------------------------------------------ progression

    private void progress(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        String sub = arg(a, 1, "/vyrnth progress <get|set|reset> <player> ...").toLowerCase(Locale.ROOT);
        OfflinePlayer op = offline(arg(a, 2, "/vyrnth progress " + sub + " <player> ..."));
        UUID id = op.getUniqueId();
        switch (sub) {
            case "get" -> {
                for (DungeonDef d : pl.dungeons().defs())
                    Msg.send(s, "<white>" + op.getName() + "</white> @ " + d.id() + ": stage " + pl.store().stage(id, d.id()) + "/" + (d.chambers() + 1)
                            + ", kings " + pl.store().bosses(id, d.id()) + ", best " + pl.store().best(id, d.id()) + "s");
            }
            case "set" -> {
                DungeonDef d = def(arg(a, 3, "/vyrnth progress set <player> <dungeon> <stage>"));
                int st = num(arg(a, 4, "/vyrnth progress set <player> <dungeon> <stage>"), 0, d.chambers() + 1);
                pl.store().setStage(id, d.id(), st);
                Msg.send(s, "Stage set to " + st + ".");
            }
            case "reset" -> {
                String d = a.length > 3 ? def(a[3]).id() : null;
                pl.store().reset(id, d);
                Msg.send(s, "Progress reset" + (d == null ? " for all dungeons." : " for " + d + "."));
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth progress <get|set|reset> <player> ...");
        }
        if (!op.isOnline()) pl.store().unload(id);
    }

    // ------------------------------------------------------------------ events

    private void event(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth event <start|stop|status|list>").toLowerCase(Locale.ROOT)) {
            case "start" -> {
                String id = arg(a, 2, "/vyrnth event start <id> [minutes]");
                int mins = a.length > 3 ? num(a[3], 1, 1440) : 30;
                if (!pl.events().start(id, mins)) throw new IllegalArgumentException("Unknown event. See /vyrnth event list");
            }
            case "stop" -> {
                if (pl.events().active() == null) throw new IllegalArgumentException("No event running.");
                pl.events().stop(true);
            }
            case "status" -> {
                EventManager.Ev ev = pl.events().active();
                Msg.send(s, ev == null ? "No rite is active." : "Active: " + ev.display() + " <gray>(" + pl.events().remainingSeconds() + "s left, mobs x"
                        + ev.mobMult() + ", rewards x" + ev.rewardMult() + ")");
            }
            case "list" -> Msg.send(s, "Events: <white>" + String.join(", ", pl.events().defs().keySet()));
            default -> throw new IllegalArgumentException("Usage: /vyrnth event <start|stop|status|list>");
        }
    }

    // ------------------------------------------------------------------ players

    private void playerCmd(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth player <list|kick|send>").toLowerCase(Locale.ROOT)) {
            case "list" -> {
                List<AccessService.Session> l = pl.access().sessions();
                if (l.isEmpty()) Msg.send(s, "Nobody is inside a dungeon.");
                for (AccessService.Session se : l) {
                    Player p = Bukkit.getPlayer(se.player());
                    Msg.send(s, "<white>" + (p == null ? se.player() : p.getName()) + "</white> in " + se.dungeon() + " for "
                            + (System.currentTimeMillis() - se.startedAt()) / 1000 + "s");
                }
            }
            case "kick" -> {
                Player p = online(arg(a, 2, "/vyrnth player kick <player>"));
                pl.access().returnToLobby(p, "admin");
                Msg.send(s, p.getName() + " returned to the lobby.");
            }
            case "send" -> {
                Player p = online(arg(a, 2, "/vyrnth player send <player> <dungeon>"));
                DungeonDef d = def(arg(a, 3, "/vyrnth player send <player> <dungeon>"));
                String err = pl.access().adminSend(p, d);
                if (err != null) throw new IllegalArgumentException(err);
                Msg.send(s, p.getName() + " sent into " + d.id() + ".");
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth player <list|kick|send>");
        }
    }

    // ------------------------------------------------------------------ blocks / debug

    private void block(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth block <list|give>").toLowerCase(Locale.ROOT)) {
            case "list" -> Msg.send(s, "Custom blocks: <white>" + Arrays.stream(CBlock.values()).map(b -> b.id).collect(Collectors.joining(", ")));
            case "give" -> {
                Player p = online(arg(a, 2, "/vyrnth block give <player> <blockId> [n]"));
                CBlock b = CBlock.byId(arg(a, 3, "/vyrnth block give <player> <blockId> [n]"));
                if (b == null) throw new IllegalArgumentException("Unknown block. See /vyrnth block list");
                p.getInventory().addItem(b.item(a.length > 4 ? num(a[4], 1, 64) : 64));
                Msg.send(s, "Gave " + b.display + ". (Place in creative; only OPs can place them.)");
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth block <list|give>");
        }
    }

    private void debug(CommandSender s, String[] a) {
        if (!Access.require(s)) return;
        switch (arg(a, 1, "/vyrnth debug <session|status|fx>").toLowerCase(Locale.ROOT)) {
            case "session" -> {
                Player p = online(arg(a, 2, "/vyrnth debug session <player>"));
                AccessService.Session se = pl.access().session(p);
                Msg.send(s, p.getName() + ": session=" + (se == null ? "none" : se.dungeon() + " prevMode=" + se.previousMode())
                        + " world=" + p.getWorld().getName() + " flagged=" + pl.store().inside(p.getUniqueId())
                        + " admin=" + Access.isAdmin(p));
            }
            case "status" -> {
                DungeonDef d = def(arg(a, 2, "/vyrnth debug status <dungeon>"));
                Instance i = pl.dungeons().instance(d.id());
                Msg.send(s, i == null || !i.ready() ? "Not built." : i.status());
            }
            case "fx" -> {
                pl.portals().refreshAll();
                Msg.send(s, "Visuals respawned.");
                if (s instanceof Player p) p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1f, 1f);
            }
            default -> throw new IllegalArgumentException("Usage: /vyrnth debug <session|status|fx>");
        }
    }

    // ------------------------------------------------------------------ tab completion (cosmetic)

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        if (!Access.isAdmin(s)) return List.of(); // non-OPs get nothing (execution is still hard-checked)
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(List.of("help", "reload", "lobby", "portal", "dungeon", "boss", "reward", "relic", "progress", "event", "player", "block", "debug"));
        } else if (a.length == 2) {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "lobby" -> out.addAll(List.of("set", "tp"));
                case "portal" -> out.addAll(List.of("build", "remove", "list", "refresh"));
                case "dungeon" -> out.addAll(List.of("list", "info", "build", "rebuild", "enable", "disable", "reset", "tp"));
                case "boss" -> out.addAll(List.of("spawn", "kill", "summon"));
                case "reward" -> out.addAll(List.of("list", "addcmd", "delcmd", "additem", "delitem", "xp", "clear"));
                case "relic" -> out.addAll(List.of("list", "give", "take"));
                case "progress" -> out.addAll(List.of("get", "set", "reset"));
                case "event" -> out.addAll(List.of("start", "stop", "status", "list"));
                case "player" -> out.addAll(List.of("list", "kick", "send"));
                case "block" -> out.addAll(List.of("list", "give"));
                case "debug" -> out.addAll(List.of("session", "status", "fx"));
                default -> { }
            }
        } else if (a.length == 3) {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "dungeon", "reward" -> pl.dungeons().defs().forEach(d -> out.add(d.id()));
                case "boss" -> { if (!a[1].equalsIgnoreCase("summon")) pl.dungeons().defs().forEach(d -> out.add(d.id())); }
                case "event" -> out.addAll(pl.events().defs().keySet());
                case "portal" -> out.addAll(pl.portals().all().keySet());
                case "relic", "block", "player", "progress" -> Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                case "debug" -> {
                    if (a[1].equalsIgnoreCase("status")) pl.dungeons().defs().forEach(d -> out.add(d.id()));
                    else Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                }
                default -> { }
            }
        } else if (a.length == 4) {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "relic" -> out.addAll(pl.relics().ids());
                case "block" -> Arrays.stream(CBlock.values()).forEach(b -> out.add(b.id));
                case "player" -> { if (a[1].equalsIgnoreCase("send")) pl.dungeons().defs().forEach(d -> out.add(d.id())); }
                case "progress" -> pl.dungeons().defs().forEach(d -> out.add(d.id()));
                default -> { }
            }
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        return out.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(last)).sorted().collect(Collectors.toList());
    }
}
