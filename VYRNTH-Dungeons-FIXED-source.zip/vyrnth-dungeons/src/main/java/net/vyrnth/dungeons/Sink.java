package net.vyrnth.dungeons;

import org.bukkit.block.data.BlockData;

@FunctionalInterface
public interface Sink {
    void set(int x, int y, int z, BlockData data);
}
