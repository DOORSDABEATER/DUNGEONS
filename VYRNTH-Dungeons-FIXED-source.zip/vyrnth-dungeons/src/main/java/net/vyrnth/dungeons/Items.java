package net.vyrnth.dungeons;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public final class Items {
    private Items() {}

    /** Generic resource-pack-skinned item. Base material is never used for vanilla behaviour. */
    public static ItemStack skinned(Material base, String modelId, String name, List<String> lore) {
        ItemStack it = new ItemStack(base);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(Keys.model(modelId.contains(":") ? modelId.substring(modelId.indexOf(':') + 1) : modelId));
        if (name != null) m.displayName(Msg.item(name));
        if (lore != null && !lore.isEmpty()) m.lore(lore.stream().map(Msg::item).toList());
        it.setItemMeta(m);
        return it;
    }

    public static ItemStack pane() {
        ItemStack it = skinned(Material.PAPER, "ui_pane", null, null);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.empty());
        m.setHideTooltip(true);
        it.setItemMeta(m);
        return it;
    }

    public static ItemStack sigil(int channelSeconds) {
        ItemStack it = skinned(Material.ECHO_SHARD, "recall_sigil", "<#9fb6ff>Recall Sigil", List.of(
                "<gray>Right-click and hold still for <white>" + channelSeconds + "s</white>",
                "<gray>to be pulled back to the lobby.",
                "<dark_gray>Bound to this descent."));
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(Keys.SIGIL, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public static boolean isSigil(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(Keys.SIGIL, PersistentDataType.BYTE);
    }

    public static boolean hasSigil(Player p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) if (isSigil(inv.getItem(i))) return true;
        return false;
    }

    public static void stripSigils(Player p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) if (isSigil(inv.getItem(i))) inv.setItem(i, null);
        if (isSigil(p.getItemOnCursor())) p.setItemOnCursor(null);
    }
}
