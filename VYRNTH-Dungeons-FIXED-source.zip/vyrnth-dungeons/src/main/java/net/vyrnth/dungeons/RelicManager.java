package net.vyrnth.dungeons;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Relics: carried items with passive potion effects, defined in relics.yml. */
public final class RelicManager {
    private record Relic(String id, String name, String model, List<String> lore, Map<PotionEffectType, Integer> effects) {}

    private final VyrnthPlugin pl;
    private final Map<String, Relic> relics = new LinkedHashMap<>();
    private BukkitTask task;

    public RelicManager(VyrnthPlugin pl) {
        this.pl = pl;
        load();
    }

    public void load() {
        relics.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(pl.getDataFolder(), "relics.yml"));
        ConfigurationSection sec = y.getConfigurationSection("relics");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(id);
            if (c == null) continue;
            Map<PotionEffectType, Integer> eff = new LinkedHashMap<>();
            for (String e : c.getStringList("effects")) {
                String[] p = e.split(":");
                PotionEffectType t = PotionEffectType.getByKey(NamespacedKey.minecraft(p[0].toLowerCase()));
                if (t == null) {
                    pl.getLogger().warning("Relic " + id + ": unknown effect '" + p[0] + "'");
                    continue;
                }
                int amp = 0;
                if (p.length > 1) try { amp = Integer.parseInt(p[1]); } catch (NumberFormatException ignored) { }
                eff.put(t, amp);
            }
            relics.put(id.toLowerCase(), new Relic(id.toLowerCase(), c.getString("name", id),
                    c.getString("model", "vyrnth:relic_ember"), c.getStringList("lore"), eff));
        }
    }

    public List<String> ids() { return new ArrayList<>(relics.keySet()); }
    public boolean exists(String id) { return relics.containsKey(id.toLowerCase()); }

    public ItemStack item(String id, int amount) {
        Relic r = relics.get(id.toLowerCase());
        if (r == null) return null;
        ItemStack it = Items.skinned(Material.ECHO_SHARD, r.model(), r.name(), r.lore());
        it.setAmount(Math.max(1, amount));
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(Keys.RELIC, PersistentDataType.STRING, r.id());
        it.setItemMeta(m);
        return it;
    }

    public String idOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(Keys.RELIC, PersistentDataType.STRING);
    }

    /** Removes up to `amount` relics of that id from the player. Returns how many were removed. */
    public int take(Player p, String id, int amount) {
        int left = amount;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize() && left > 0; i++) {
            ItemStack it = inv.getItem(i);
            if (!id.equalsIgnoreCase(idOf(it))) continue;
            int n = Math.min(left, it.getAmount());
            it.setAmount(it.getAmount() - n);
            if (it.getAmount() <= 0) inv.setItem(i, null);
            left -= n;
        }
        return amount - left;
    }

    public void start() {
        if (task != null) task.cancel();
        task = Bukkit.getScheduler().runTaskTimer(pl, () -> {
            boolean onlyDungeon = pl.getConfig().getBoolean("relics.only-in-dungeon", true);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (onlyDungeon && !pl.dungeons().isDungeonWorld(p.getWorld().getName())) continue;
                PlayerInventory inv = p.getInventory();
                for (int i = 0; i < inv.getSize(); i++) {
                    String id = idOf(inv.getItem(i));
                    if (id == null) continue;
                    Relic r = relics.get(id);
                    if (r == null) continue;
                    r.effects().forEach((t, amp) -> p.addPotionEffect(new PotionEffect(t, 100, amp, true, false, true)));
                }
            }
        }, 40L, 40L);
    }

    public void stop() {
        if (task != null) task.cancel();
    }
}
