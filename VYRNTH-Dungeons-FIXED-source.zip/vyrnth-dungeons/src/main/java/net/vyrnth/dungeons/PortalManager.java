package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Registry + visuals for physical gateways: LOBBY (entry) and RETURN (inside dungeons). */
public final class PortalManager {
    public enum Kind { LOBBY, RETURN }

    public static final class Rec {
        public final String id;
        public final Kind kind;
        public final String world;
        public final int x, y, z;
        public final BlockFace facing;
        /** "x,y,z" -> previous block data string (lobby portals only, for /portal remove). */
        public final Map<String, String> undo = new LinkedHashMap<>();
        public Frame frame;
        public BoundingBox trigger, structure;
        public Location opening;

        Rec(String id, Kind kind, String world, int x, int y, int z, BlockFace facing) {
            this.id = id;
            this.kind = kind;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.facing = facing;
        }

        String tag() {
            return "vyrnth_fx_" + id;
        }
    }

    private final VyrnthPlugin pl;
    private final File file;
    private final Map<String, Rec> portals = new LinkedHashMap<>();
    private BukkitTask fx;

    public PortalManager(VyrnthPlugin pl) {
        this.pl = pl;
        this.file = new File(pl.getDataFolder(), "portals.yml");
    }

    // ------------------------------------------------------------------ persistence

    /** Idempotent: safe to call again when more worlds load. */
    public void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("portals");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(id);
            if (c == null) continue;
            Rec existing = portals.get(id);
            if (existing != null && existing.frame != null) continue;
            BlockFace face;
            Kind kind;
            try {
                face = BlockFace.valueOf(c.getString("facing", "SOUTH"));
                kind = Kind.valueOf(c.getString("kind", "LOBBY"));
            } catch (IllegalArgumentException ex) {
                pl.getLogger().warning("Bad portal entry " + id);
                continue;
            }
            Rec r = new Rec(id, kind, c.getString("world", ""), c.getInt("x"), c.getInt("y"), c.getInt("z"), face);
            for (String u : c.getStringList("undo")) {
                int i = u.indexOf('|');
                if (i > 0) r.undo.put(u.substring(0, i), u.substring(i + 1));
            }
            portals.put(id, r);
            if (resolve(r)) ensureVisuals(r);
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Rec r : portals.values()) {
            String p = "portals." + r.id + ".";
            y.set(p + "kind", r.kind.name());
            y.set(p + "world", r.world);
            y.set(p + "x", r.x);
            y.set(p + "y", r.y);
            y.set(p + "z", r.z);
            y.set(p + "facing", r.facing.name());
            List<String> u = new ArrayList<>();
            r.undo.forEach((k, v) -> u.add(k + "|" + v));
            if (!u.isEmpty()) y.set(p + "undo", u);
        }
        try {
            y.save(file);
        } catch (IOException e) {
            pl.getLogger().warning("Could not save portals.yml: " + e.getMessage());
        }
    }

    private boolean resolve(Rec r) {
        World w = Bukkit.getWorld(r.world);
        if (w == null) return false;
        r.frame = new Frame(w, r.x, r.y, r.z, r.facing);
        r.trigger = r.frame.cells(-1, 1, 0, 1, 5, 1);
        r.structure = r.frame.cells(-Gateway.RA, 0, -Gateway.RD, Gateway.RA, Gateway.HT, Gateway.RD);
        r.opening = Gateway.openingCenter(r.frame);
        return true;
    }

    // ------------------------------------------------------------------ building

    /** Builds a lobby gateway 5 blocks in front of the admin, facing back toward them. */
    public String buildLobby(String id, Player p) {
        if (portals.containsKey(id)) return "A gateway named '" + id + "' already exists.";
        BlockFace look = p.getFacing();
        if (look.getModY() != 0 || look.getModX() * look.getModZ() != 0) look = BlockFace.NORTH; // cardinal only
        BlockFace out = look.getOppositeFace();
        Location l = p.getLocation();
        int bx = l.getBlockX() + look.getModX() * 5;
        int bz = l.getBlockZ() + look.getModZ() * 5;
        int by = l.getBlockY() - 1;
        World w = p.getWorld();
        Rec r = new Rec(id, Kind.LOBBY, w.getName(), bx, by, bz, out);
        r.frame = new Frame(w, bx, by, bz, out);
        Sink undoSink = (x, y, z, d) -> {
            Block b = w.getBlockAt(x, y, z);
            r.undo.putIfAbsent(x + "," + y + "," + z, b.getBlockData().getAsString());
            b.setBlockData(d, false);
        };
        Gateway.build(r.frame, undoSink);
        resolve(r);
        portals.put(id, r);
        save();
        ensureVisuals(r);
        return null;
    }

    /** Registers (and decorates) a return gate that the dungeon builder already placed. */
    public void registerReturn(String id, World w, int x, int y, int z, BlockFace facing) {
        Rec old = portals.remove(id);
        if (old != null) clearVisuals(old);
        Rec r = new Rec(id, Kind.RETURN, w.getName(), x, y, z, facing);
        resolve(r);
        portals.put(id, r);
        save();
        ensureVisuals(r);
    }

    public String remove(String id) {
        Rec r = portals.remove(id);
        if (r == null) return "No gateway named '" + id + "'.";
        clearVisuals(r);
        World w = Bukkit.getWorld(r.world);
        if (w != null && !r.undo.isEmpty()) {
            for (Map.Entry<String, String> e : r.undo.entrySet()) {
                String[] p = e.getKey().split(",");
                try {
                    BlockData d = Bukkit.createBlockData(e.getValue());
                    w.getBlockAt(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])).setBlockData(d, false);
                } catch (Exception ignored) {
                }
            }
        }
        save();
        return null;
    }

    /** Called when a dungeon is rebuilt/deleted: drop its return gate without restoring anything. */
    public void forget(String id) {
        Rec r = portals.remove(id);
        if (r != null) clearVisuals(r);
        save();
    }

    // ------------------------------------------------------------------ visuals

    public void ensureVisuals(Rec r) {
        if (r.frame == null) return;
        clearVisuals(r);
        Gateway.spawnMembrane(r.frame, r.tag());
    }

    public void refreshAll() {
        for (Rec r : portals.values()) {
            if (r.frame == null) resolve(r);
            ensureVisuals(r);
        }
    }

    private void clearVisuals(Rec r) {
        if (r.frame == null) return;
        World w = r.frame.world;
        int minCx = (int) Math.floor(r.structure.getMinX()) >> 4, maxCx = (int) Math.floor(r.structure.getMaxX()) >> 4;
        int minCz = (int) Math.floor(r.structure.getMinZ()) >> 4, maxCz = (int) Math.floor(r.structure.getMaxZ()) >> 4;
        for (int cx = minCx; cx <= maxCx; cx++) for (int cz = minCz; cz <= maxCz; cz++) w.getChunkAt(cx, cz);
        for (Entity e : w.getNearbyEntities(r.structure.clone().expand(2), en -> en.getScoreboardTags().contains(r.tag()))) {
            e.remove();
        }
    }

    public void startFx() {
        if (fx != null) fx.cancel();
        fx = new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t += 4;
                for (Rec r : portals.values()) {
                    if (r.frame == null) continue;
                    World w = r.frame.world;
                    if (w.getNearbyPlayers(r.opening, 48).isEmpty()) continue;
                    fx(r, w, t);
                }
            }
        }.runTaskTimer(pl, 20L, 4L);
    }

    private void fx(Rec r, World w, int t) {
        Frame f = r.frame;
        Location o = r.opening;
        double ox = f.rx != 0 ? 0.9 : 0.15, oz = f.rz != 0 ? 0.9 : 0.15;
        w.spawnParticle(Particle.REVERSE_PORTAL, o, 6, ox, 1.8, oz, 0.02);
        w.spawnParticle(Particle.ENCHANT, o, 8, ox * 1.6, 2.6, oz * 1.6, 0.6);
        // rotating dust ring on the plane of the opening
        double ang = t * 0.12;
        for (int k = 0; k < 3; k++) {
            double a = ang + k * (Math.PI * 2 / 3);
            double ca = Math.cos(a) * 1.45, sa = Math.sin(a) * 2.45;
            Color c = k % 2 == 0 ? Color.fromRGB(150, 90, 255) : Color.fromRGB(45, 226, 230);
            w.spawnParticle(Particle.DUST, o.getX() + f.rx * ca, o.getY() + sa, o.getZ() + f.rz * ca,
                    1, 0, 0, 0, 0, new Particle.DustOptions(c, 1.3f));
        }
        if (t % 100 == 0) w.playSound(o, Sound.BLOCK_BEACON_AMBIENT, 0.6f, 0.5f);
        if (t % 240 == 0) w.playSound(o, Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD, 0.8f, 0.6f);
        if (t % 400 == 0) w.playSound(o, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.7f, 0.5f);
    }

    public void shutdown() {
        if (fx != null) fx.cancel();
    }

    // ------------------------------------------------------------------ queries

    public Map<String, Rec> all() {
        return portals;
    }

    /** Portal whose walk-in trigger contains this location, or null. */
    public Rec at(Location l) {
        for (Rec r : portals.values()) {
            if (r.trigger == null || !r.frame.world.equals(l.getWorld())) continue;
            if (r.trigger.contains(l.getX(), l.getY(), l.getZ())) return r;
        }
        return null;
    }

    public Rec structureAt(Block b) {
        for (Rec r : portals.values()) {
            if (r.structure == null || !r.frame.world.equals(b.getWorld())) continue;
            if (r.structure.contains(b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5)) return r;
        }
        return null;
    }

    public boolean nearLobbyPortal(Player p, double dist) {
        for (Rec r : portals.values()) {
            if (r.kind != Kind.LOBBY || r.opening == null || !r.frame.world.equals(p.getWorld())) continue;
            if (r.opening.distanceSquared(p.getLocation()) <= dist * dist) return true;
        }
        return false;
    }

    public boolean hasLobbyPortal() {
        return portals.values().stream().anyMatch(r -> r.kind == Kind.LOBBY && r.frame != null);
    }
}
