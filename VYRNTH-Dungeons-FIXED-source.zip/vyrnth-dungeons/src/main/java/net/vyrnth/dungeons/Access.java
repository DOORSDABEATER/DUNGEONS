package net.vyrnth.dungeons;

import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.RemoteConsoleCommandSender;
import org.bukkit.entity.Player;

/**
 * The ONE place that decides who may administer VYRNTH.
 * Hard-wired to server OP status or console. It is deliberately NOT driven by config or by
 * permission nodes, so a permissions plugin or a config typo can never hand admin access
 * to a regular player. Command blocks / minecarts / other senders are denied.
 */
public final class Access {
    private Access() {}

    public static boolean isAdmin(CommandSender s) {
        if (s instanceof Player p) return p.isOp();
        return s instanceof ConsoleCommandSender || s instanceof RemoteConsoleCommandSender;
    }

    /** Returns true if allowed; otherwise tells the sender no and returns false. */
    public static boolean require(CommandSender s) {
        if (isAdmin(s)) return true;
        Msg.err(s, "The ancient seals do not answer to you. <dark_gray>(OP only)");
        return false;
    }
}
