package net.vyrnth.dungeons;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Deterministic dungeon layout generated from (seed, chambers). Pure geometry: nothing here touches the
 * world until paint() is turned into blocks by DungeonManager. A line of rooms runs along +X:
 *
 *   [Antechamber + Return Gate] -> corridor -> [Chamber 1] -> seal -> ... -> [Chamber N] -> seal -> [Boss Arena]
 */
public final class Layout {
    public static final int Y0 = 100;          // floor level
    public static final int LC = 6;            // corridor length
    public static final int ARENA_R = 17, ARENA_H = 14;
    public static final int GATE_X = 4, GATE_Z = 0;
    private static final BlockData AIR = Material.AIR.createBlockData();

    public static final class Room {
        public int index, x0, x1, hw, h, mode;
        public BoundingBox interior;
        public final List<Vector> spawns = new ArrayList<>();
        /** Exit seal cells {x,y,z}; empty for the antechamber. */
        public final List<int[]> seal = new ArrayList<>();
        public final Set<Long> pillars = new HashSet<>();
        public Vector entry;
    }

    public final long seed;
    public final int chambers;
    public final List<Room> rooms = new ArrayList<>();
    public int arenaX0, arenaCx;
    public BoundingBox arenaBox;
    public final List<int[]> arenaSeal = new ArrayList<>();
    public Vector arenaCenter;

    public Layout(DungeonDef def) {
        this.seed = def.seed();
        this.chambers = def.chambers();
        Random r = new Random(seed);
        int x = 0;
        for (int i = 0; i <= chambers; i++) {
            Room rm = new Room();
            rm.index = i;
            rm.x0 = x;
            int len = i == 0 ? 19 : 15 + 2 * r.nextInt(4);
            rm.hw = i == 0 ? 11 : 7 + 2 * r.nextInt(3);
            rm.h = i == 0 ? 12 : 7 + r.nextInt(2);
            rm.mode = i == 0 ? 0 : r.nextInt(3);
            rm.x1 = x + len - 1;
            rm.interior = new BoundingBox(rm.x0 + 1, Y0 + 1, -rm.hw + 1, rm.x1, Y0 + rm.h, rm.hw);
            rm.entry = i == 0 ? new Vector(10.5, Y0 + 1, 0.5) : new Vector(rm.x0 + 2.5, Y0 + 1, 0.5);
            if (i >= 1) {
                for (int z = -1; z <= 1; z++) for (int y = 1; y <= 4; y++) rm.seal.add(new int[]{rm.x1, Y0 + y, z});
                if (rm.mode == 0) {
                    for (int px = rm.x0 + 5; px <= rm.x1 - 4; px += 5)
                        for (int sg = -1; sg <= 1; sg += 2) rm.pillars.add(pack(px, 0, sg * (rm.hw / 2)));
                }
                for (int sx = rm.x0 + 6; sx <= rm.x1 - 2; sx += 3)
                    for (int sz = -rm.hw + 2; sz <= rm.hw - 2; sz += 3) {
                        if (nearPillar(rm, sx, sz)) continue;
                        rm.spawns.add(new Vector(sx + 0.5, Y0 + 1, sz + 0.5));
                    }
            }
            rooms.add(rm);
            x = rm.x1 + LC + 1;
        }
        arenaX0 = x;
        arenaCx = x + ARENA_R + 1;
        arenaBox = new BoundingBox(arenaCx - ARENA_R, Y0 + 1, -ARENA_R, arenaCx + ARENA_R + 1, Y0 + ARENA_H, ARENA_R + 1);
        arenaCenter = new Vector(arenaCx + 0.5, Y0 + 1, 0.5);
        for (int z = -1; z <= 1; z++) for (int y = 1; y <= 4; y++) arenaSeal.add(new int[]{arenaX0, Y0 + y, z});
    }

    private static boolean nearPillar(Room rm, int x, int z) {
        for (long k : rm.pillars) if (Math.abs(ux(k) - x) <= 1 && Math.abs(uz(k) - z) <= 1) return true;
        return false;
    }

    public Room room(int i) { return rooms.get(i); }

    // --------------------------------------------------------------- painting

    public Map<Long, BlockData> paint(World w) {
        Map<Long, BlockData> m = new LinkedHashMap<>();
        Sink s = (x, y, z, d) -> m.put(pack(x, y, z), d);
        for (Room rm : rooms) paintRoom(rm, s);
        for (Room rm : rooms) paintCorridor(rm.x1, s);
        paintArena(s);
        for (Room rm : rooms) for (int[] c : rm.seal) s.set(c[0], c[1], c[2], CBlock.RITUAL_SEAL.data());
        Gateway.build(new Frame(w, GATE_X, Y0, GATE_Z, BlockFace.EAST), s);
        return m;
    }

    private void paintRoom(Room rm, Sink s) {
        int x0 = rm.x0, x1 = rm.x1, hw = rm.hw, top = Y0 + rm.h;
        for (int x = x0; x <= x1; x++) {
            for (int z = -hw; z <= hw; z++) {
                s.set(x, Y0, z, floor(rm, x, z));
                s.set(x, top, z, hash(x, z) % 6 == 0 ? CBlock.RUIN_BRICK.data() : CBlock.VOID_OBSIDIAN.data());
                boolean wall = x == x0 || x == x1 || z == -hw || z == hw;
                if (!wall) continue;
                for (int y = Y0 + 1; y < top; y++) {
                    boolean door = (x == x1 || (x == x0 && rm.index >= 1)) && Math.abs(z) <= 1 && y <= Y0 + 4;
                    if (door) continue;
                    s.set(x, y, z, wall(x, y, z));
                }
            }
        }
        for (int x = x0 + 4; x <= x1 - 3; x += 6) {
            for (int z : new int[]{-hw + 3, 0, hw - 3}) s.set(x, top - 1, z, Gateway.light(13));
            for (int sg = -1; sg <= 1; sg += 2) {
                s.set(x, Y0 + 1, sg * (hw - 1), CBlock.BRAZIER.data());
                s.set(x, Y0 + 2, sg * (hw - 1), Gateway.light(14));
            }
        }
        for (long pk : rm.pillars) {
            int px = ux(pk), pz = uz(pk);
            for (int y = Y0 + 1; y < top; y++) s.set(px, y, pz, CBlock.GILDED_PILLAR.data());
        }
    }

    private BlockData floor(Room rm, int x, int z) {
        int h = hash(x, z);
        if (rm.mode == 1) {
            double cx = (rm.x0 + rm.x1) / 2.0, d = Math.hypot(x - cx, z);
            double rr = Math.min(rm.hw - 2, 6);
            if (d < 2.5) return CBlock.ECLIPSE_TILE.data();
            if (d <= rr && d >= rr - 1) return CBlock.SIGIL_FLOOR.data();
            if (d < rr && h % 3 == 0) return CBlock.SIGIL_FLOOR.data();
        }
        if (rm.mode == 2 && h % 4 == 0) return CBlock.OVERGROWN_RUIN.data();
        if (h % 9 == 0) return CBlock.BONE_MORTAR.data();
        return CBlock.FLAGSTONE.data();
    }

    private BlockData wall(int x, int y, int z) {
        if (y == Y0 + 3 && (x + z) % 4 == 0) return CBlock.CARVED_RUNESTONE.data();
        if (y <= Y0 + 3 && hash(x * 7 + y, z * 13 + x) % 11 == 0) return CBlock.OVERGROWN_RUIN.data();
        return CBlock.RUIN_BRICK.data();
    }

    private void paintCorridor(int fromX, Sink s) {
        for (int x = fromX + 1; x <= fromX + LC; x++) {
            for (int z = -2; z <= 2; z++) {
                s.set(x, Y0, z, hash(x, z) % 7 == 0 ? CBlock.BONE_MORTAR.data() : CBlock.FLAGSTONE.data());
                s.set(x, Y0 + 5, z, CBlock.VOID_OBSIDIAN.data());
            }
            for (int y = Y0 + 1; y <= Y0 + 4; y++)
                for (int sg = -1; sg <= 1; sg += 2)
                    s.set(x, y, 2 * sg, y == Y0 + 3 && x % 2 == 0 ? CBlock.CARVED_RUNESTONE.data() : CBlock.RUIN_BRICK.data());
            if ((x - fromX) % 3 == 0) s.set(x, Y0 + 4, 0, Gateway.light(9));
        }
    }

    private void paintArena(Sink s) {
        int cx = arenaCx, R = ARENA_R, top = Y0 + ARENA_H;
        double outer = R + 1.5;
        for (int x = cx - R - 2; x <= cx + R + 2; x++) {
            for (int z = -R - 2; z <= R + 2; z++) {
                double d2 = (double) (x - cx) * (x - cx) + (double) z * z;
                if (d2 > outer * outer) continue;
                double d = Math.sqrt(d2);
                s.set(x, Y0, z, arenaFloor(d, x, z));
                s.set(x, top, z, hash(x, z) % 5 == 0 ? CBlock.RUIN_BRICK.data() : CBlock.VOID_OBSIDIAN.data());
                if (d2 <= (double) R * R) continue;
                for (int y = Y0 + 1; y < top; y++) {
                    if (x <= arenaX0 + 1 && Math.abs(z) <= 1 && y <= Y0 + 4) continue; // doorway
                    boolean band = y == Y0 + 4 || y == top - 2;
                    s.set(x, y, z, band ? CBlock.CARVED_RUNESTONE.data() : CBlock.RUIN_BRICK.data());
                }
            }
        }
        for (int k = 0; k < 8; k++) {
            double ang = k * Math.PI / 4 + Math.PI / 8;
            int px = cx + (int) Math.round(11 * Math.cos(ang)), pz = (int) Math.round(11 * Math.sin(ang));
            for (int dx = 0; dx <= 1; dx++)
                for (int dz = 0; dz <= 1; dz++)
                    for (int y = Y0 + 1; y < top; y++) s.set(px + dx, y, pz + dz, CBlock.GILDED_PILLAR.data());
        }
        for (int k = 0; k < 16; k++) {
            double ang = k * Math.PI / 8;
            int bx = cx + (int) Math.round(14.5 * Math.cos(ang)), bz = (int) Math.round(14.5 * Math.sin(ang));
            s.set(bx, Y0 + 1, bz, CBlock.BRAZIER.data());
            s.set(bx, Y0 + 2, bz, Gateway.light(15));
        }
        for (int k = 0; k < 12; k++) {
            double ang = k * Math.PI / 6;
            s.set(cx + (int) Math.round(9 * Math.cos(ang)), top - 1, (int) Math.round(9 * Math.sin(ang)), Gateway.light(13));
            s.set(cx + (int) Math.round(15 * Math.cos(ang)), top - 1, (int) Math.round(15 * Math.sin(ang)), Gateway.light(13));
        }
    }

    private BlockData arenaFloor(double d, int x, int z) {
        if (d < 3.5) return CBlock.ECLIPSE_TILE.data();
        if (d < 4.5) return CBlock.ANCIENT_GOLD.data();
        if (d > 7.5 && d < 8.5) return CBlock.SIGIL_FLOOR.data();
        if (d > 12.5 && d < 13.5) return CBlock.ECLIPSE_TILE.data();
        return hash(x, z) % 8 == 0 ? CBlock.BONE_MORTAR.data() : CBlock.FLAGSTONE.data();
    }

    private int hash(int a, int b) {
        long v = seed ^ (a * 0x9E3779B97F4A7C15L) ^ (b * 0xC2B2AE3D27D4EB4FL);
        v ^= v >>> 33;
        v *= 0xff51afd7ed558ccdL;
        v ^= v >>> 33;
        return (int) (v & 0x7fffffffL);
    }

    public static BlockData air() { return AIR; }

    // --------------------------------------------------------------- packing (BlockPos-style)
    public static long pack(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }
    public static int ux(long k) { return (int) (k >> 38); }
    public static int uz(long k) { return (int) (k << 26 >> 38); }
    public static int uy(long k) { return (int) (k & 0xFFF); }
}
