package net.vyrnth.dungeons;

import org.bukkit.NamespacedKey;

/** All persistent-data / item-model keys live in the fixed "vyrnth" namespace (matches the resource pack). */
public final class Keys {
    private Keys() {}
    public static final NamespacedKey CBLOCK = new NamespacedKey("vyrnth", "cblock");
    public static final NamespacedKey SIGIL = new NamespacedKey("vyrnth", "sigil");
    public static final NamespacedKey RELIC = new NamespacedKey("vyrnth", "relic");
    public static final NamespacedKey MOB = new NamespacedKey("vyrnth", "dmob");

    public static NamespacedKey model(String id) {
        return new NamespacedKey("vyrnth", id);
    }
}
