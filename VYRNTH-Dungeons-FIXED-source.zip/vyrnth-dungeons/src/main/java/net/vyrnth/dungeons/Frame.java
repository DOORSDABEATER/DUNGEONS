package net.vyrnth.dungeons;

import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.util.BoundingBox;

/**
 * Local coordinate frame for a structure. a = across, y = up, d = depth (positive d points OUT of the
 * structure, toward the side players approach from). Cardinal facings only.
 */
public final class Frame {
    public final World world;
    public final int ox, oy, oz, fx, fz, rx, rz;
    public final BlockFace facing;

    public Frame(World world, int ox, int oy, int oz, BlockFace facing) {
        this.world = world;
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.facing = facing;
        this.fx = facing.getModX();
        this.fz = facing.getModZ();
        this.rx = -fz;
        this.rz = fx;
    }

    public int x(int a, int d) {
        return ox + rx * a + fx * d;
    }

    public int z(int a, int d) {
        return oz + rz * a + fz * d;
    }

    public void put(Sink s, int a, int y, int d, BlockData data) {
        s.set(x(a, d), oy + y, z(a, d), data);
    }

    /** Inclusive cell range in local coords -> world-space bounding box. */
    public BoundingBox cells(int a1, int y1, int d1, int a2, int y2, int d2) {
        int xa = x(a1, d1), xb = x(a2, d2), za = z(a1, d1), zb = z(a2, d2);
        return new BoundingBox(
                Math.min(xa, xb), oy + Math.min(y1, y2), Math.min(za, zb),
                Math.max(xa, xb) + 1, oy + Math.max(y1, y2) + 1, Math.max(za, zb) + 1);
    }
}
