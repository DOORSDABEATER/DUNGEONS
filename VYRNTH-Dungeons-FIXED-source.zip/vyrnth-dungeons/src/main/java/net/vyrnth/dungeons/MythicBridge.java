package net.vyrnth.dungeons;

import io.lumine.mythic.bukkit.MythicBukkit;
import io.lumine.mythic.core.mobs.ActiveMob;
import org.bukkit.Location;
import org.bukkit.entity.Entity;

/**
 * The ONLY class that touches the MythicMobs API. It is instantiated only when MythicMobs is enabled,
 * so the plugin runs fine (with vanilla fallback mobs) without it. If a MythicMobs update changes its API,
 * this is the single file to adjust.
 */
public final class MythicBridge {
    private final MythicBukkit mm = MythicBukkit.inst();

    public boolean has(String type) {
        return type != null && !type.isBlank() && mm.getMobManager().getMythicMob(type).isPresent();
    }

    /** Spawns a MythicMob; returns null if the type does not exist. */
    public Entity spawn(String type, Location loc) {
        if (!has(type)) return null;
        ActiveMob am = mm.getMobManager().spawnMob(type, loc);
        return am == null ? null : am.getEntity().getBukkitEntity();
    }

    /** Casts a MythicMobs skill with `caster` as the source. */
    public boolean cast(Entity caster, String skill) {
        if (skill == null || skill.isBlank()) return false;
        return mm.getAPIHelper().castSkill(caster, skill);
    }
}
