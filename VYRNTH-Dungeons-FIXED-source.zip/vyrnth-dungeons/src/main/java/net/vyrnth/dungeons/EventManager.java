package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.scheduler.BukkitTask;

import java.util.LinkedHashMap;
import java.util.Map;

/** Timed server-wide rites (events) that scale mob waves and rewards. */
public final class EventManager {
    public record Ev(String id, String display, double mobMult, double rewardMult) {}

    private final VyrnthPlugin pl;
    private final Map<String, Ev> defs = new LinkedHashMap<>();
    private Ev active;
    private long endsAt;
    private BukkitTask task;

    public EventManager(VyrnthPlugin pl) {
        this.pl = pl;
        load();
    }

    public void load() {
        defs.clear();
        ConfigurationSection s = pl.getConfig().getConfigurationSection("events");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(id);
            if (c == null) continue;
            defs.put(id.toLowerCase(), new Ev(id.toLowerCase(), c.getString("display", id),
                    Math.max(0.1, c.getDouble("mob-multiplier", 1)), Math.max(0.1, c.getDouble("reward-multiplier", 1))));
        }
    }

    public Map<String, Ev> defs() { return defs; }
    public Ev active() { return active; }
    public double mobMult() { return active == null ? 1.0 : active.mobMult(); }
    public double rewardMult() { return active == null ? 1.0 : active.rewardMult(); }
    public long remainingSeconds() { return active == null ? 0 : Math.max(0, (endsAt - System.currentTimeMillis()) / 1000); }

    public boolean start(String id, int minutes) {
        Ev ev = defs.get(id.toLowerCase());
        if (ev == null) return false;
        stop(false);
        active = ev;
        endsAt = System.currentTimeMillis() + minutes * 60_000L;
        task = Bukkit.getScheduler().runTaskLater(pl, () -> stop(true), minutes * 60L * 20L);
        Bukkit.broadcast(Msg.mm(Msg.PREFIX + "<gray>The rite of " + ev.display() + "<gray> begins. The gateway hums louder... <dark_gray>("
                + minutes + "m)"));
        return true;
    }

    public void stop(boolean announce) {
        if (task != null) task.cancel();
        task = null;
        if (active != null && announce) Bukkit.broadcast(Msg.mm(Msg.PREFIX + "<gray>The rite of " + active.display() + "<gray> fades."));
        active = null;
    }
}
