package net.vyrnth.dungeons;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sessions, the lobby, and EVERY teleport into/out of dungeons. All entry validation happens here, server-side.
 * Teleports into dungeon worlds are only legal while a one-shot token (tokens) is set by this class.
 */
public final class AccessService {
    public record Session(UUID player, String dungeon, long startedAt, GameMode previousMode) {}

    private final VyrnthPlugin pl;
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();
    private final Set<UUID> tokens = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Long> entryCooldown = new HashMap<>();
    private final Map<UUID, Long> menuCooldown = new HashMap<>();
    private final Map<UUID, BukkitTask> recalls = new HashMap<>();

    public AccessService(VyrnthPlugin pl) {
        this.pl = pl;
    }

    // ------------------------------------------------------------------ lobby

    public Location lobby() {
        var d = pl.data();
        String w = d.getString("lobby.world");
        World world = w == null ? null : Bukkit.getWorld(w);
        if (world != null) {
            return new Location(world, d.getDouble("lobby.x"), d.getDouble("lobby.y"), d.getDouble("lobby.z"),
                    (float) d.getDouble("lobby.yaw"), (float) d.getDouble("lobby.pitch"));
        }
        String fb = pl.getConfig().getString("lobby.fallback-world", "");
        World f = fb.isEmpty() ? null : Bukkit.getWorld(fb);
        if (f == null) f = Bukkit.getWorlds().get(0);
        return f.getSpawnLocation().add(0.5, 0, 0.5);
    }

    public void setLobby(Location l) {
        var d = pl.data();
        d.set("lobby.world", l.getWorld().getName());
        d.set("lobby.x", l.getX());
        d.set("lobby.y", l.getY());
        d.set("lobby.z", l.getZ());
        d.set("lobby.yaw", l.getYaw());
        d.set("lobby.pitch", l.getPitch());
        pl.saveData();
    }

    // ------------------------------------------------------------------ queries

    public boolean hasSession(Player p) { return sessions.containsKey(p.getUniqueId()); }
    public Session session(Player p) { return sessions.get(p.getUniqueId()); }
    public boolean hasToken(Player p) { return tokens.contains(p.getUniqueId()); }

    /** Players with a live session in this dungeon who are physically in its world. */
    public List<Player> playersIn(String dungeonId) {
        List<Player> out = new ArrayList<>();
        for (Session s : sessions.values()) {
            if (!s.dungeon().equals(dungeonId)) continue;
            Player p = Bukkit.getPlayer(s.player());
            if (p != null && p.isOnline() && pl.dungeons().isDungeonWorld(p.getWorld().getName())) out.add(p);
        }
        return out;
    }

    public List<Session> sessions() { return new ArrayList<>(sessions.values()); }

    // ------------------------------------------------------------------ portal interaction

    /** Walk-in / click on the lobby gateway: open the selection menu (rate-limited) and nudge the player back. */
    public void openPortal(Player p, PortalManager.Rec r) {
        if (hasSession(p) || p.isDead()) return;
        long now = System.currentTimeMillis();
        Long last = menuCooldown.get(p.getUniqueId());
        if (last != null && now - last < 2000) return;
        menuCooldown.put(p.getUniqueId(), now);
        if (r.frame != null) p.setVelocity(new Vector(r.frame.fx * 0.45, 0.15, r.frame.fz * 0.45));
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1f, 0.6f);
        p.openInventory(new PortalMenu(pl, p).getInventory());
    }

    // ------------------------------------------------------------------ entering

    /**
     * Validates and performs an entry. Returns an error string, or null on success.
     * adminBypass is ONLY passed by OP-checked admin commands; the portal menu always passes false.
     */
    public String enter(Player p, DungeonDef d, boolean resume, boolean adminBypass) {
        UUID id = p.getUniqueId();
        if (!p.isOnline() || p.isDead()) return "You cannot descend right now.";
        if (sessions.containsKey(id)) return "You are already inside a dungeon.";
        if (!adminBypass) {
            Location lobby = lobby();
            if (!p.getWorld().equals(lobby.getWorld())) return "The gateway only answers in the lobby.";
            double max = pl.getConfig().getDouble("entry.max-distance-from-portal", 10);
            if (!pl.portals().nearLobbyPortal(p, max)) return "Step closer to the gateway.";
            long cd = pl.getConfig().getLong("entry.cooldown-seconds", 5) * 1000L;
            Long last = entryCooldown.get(id);
            if (last != null && System.currentTimeMillis() - last < cd) return "The gateway is still settling...";
        }
        Instance inst = pl.dungeons().instance(d.id());
        if (!d.enabled() || inst == null || !inst.ready()) return "This realm is sealed for now.";

        int stage = pl.store().stage(id, d.id());
        Location dest = resume && stage > 0 ? inst.checkpoint(stage) : inst.entrance();
        dest.getWorld().getChunkAt(dest);

        Location from = p.getLocation();
        Session s = new Session(id, d.id(), System.currentTimeMillis(), p.getGameMode());
        sessions.put(id, s);
        pl.store().setInside(id, d.id(), s.previousMode());
        entryCooldown.put(id, System.currentTimeMillis());
        if (!tp(p, dest)) {
            sessions.remove(id);
            pl.store().clearInside(id);
            return "The gateway refused you.";
        }
        p.setGameMode(GameMode.ADVENTURE);
        p.setFallDistance(0);
        p.setFireTicks(0);
        if (!Items.hasSigil(p)) p.getInventory().addItem(Items.sigil(pl.getConfig().getInt("recall.channel-seconds", 5)));

        from.getWorld().spawnParticle(Particle.REVERSE_PORTAL, from.clone().add(0, 1, 0), 60, 0.4, 0.8, 0.4, 0.2);
        from.getWorld().playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 0.5f);
        dest.getWorld().spawnParticle(Particle.REVERSE_PORTAL, dest.clone().add(0, 1, 0), 80, 0.5, 1, 0.5, 0.3);
        dest.getWorld().playSound(dest, Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD, 1f, 0.5f);
        p.showTitle(Title.title(Msg.mm(d.display()), Msg.mm("<gray>" + (resume && stage > 0 ? "You return to the dark..." : "The gateway closes behind you.")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofSeconds(1))));
        return null;
    }

    // ------------------------------------------------------------------ leaving

    /** Ends the session and teleports the player to the lobby. Safe to call with no session (recovery). */
    public void returnToLobby(Player p, String why) {
        UUID id = p.getUniqueId();
        Session s = sessions.remove(id);
        cancelRecall(id);
        GameMode restore = s != null ? s.previousMode() : pl.store().storedMode(id);
        Items.stripSigils(p);
        pl.dungeons().onLeave(p);
        Location lobby = lobby();
        Location from = p.getLocation();
        p.setFallDistance(0);
        p.setFireTicks(0);
        if (!tp(p, lobby)) pl.getLogger().warning("Could not return " + p.getName() + " to the lobby (" + why + ")");
        p.setGameMode(restore);
        pl.store().clearInside(id);
        from.getWorld().spawnParticle(Particle.REVERSE_PORTAL, from.clone().add(0, 1, 0), 50, 0.4, 0.8, 0.4, 0.2);
        lobby.getWorld().playSound(lobby, Sound.BLOCK_END_PORTAL_SPAWN, 0.6f, 1.5f);
        if (!"quiet".equals(why)) p.sendActionBar(Msg.mm("<gray>The gateway releases you."));
    }

    /** Death in a dungeon: respawn in the lobby, restore state. Progress is kept. */
    public void onRespawn(Player p, org.bukkit.event.player.PlayerRespawnEvent e) {
        UUID id = p.getUniqueId();
        Session s = sessions.remove(id);
        boolean inDungeonRespawn = e.getRespawnLocation().getWorld() != null
                && pl.dungeons().isDungeonWorld(e.getRespawnLocation().getWorld().getName());
        if (s == null && !(inDungeonRespawn && !Access.isAdmin(p))) return;
        cancelRecall(id);
        e.setRespawnLocation(lobby());
        GameMode restore = s != null ? s.previousMode() : pl.store().storedMode(id);
        pl.store().clearInside(id);
        Bukkit.getScheduler().runTask(pl, () -> {
            p.setGameMode(restore);
            Items.stripSigils(p);
            pl.dungeons().onLeave(p);
        });
    }

    public void onQuit(Player p) {
        sessions.remove(p.getUniqueId());
        tokens.remove(p.getUniqueId());
        cancelRecall(p.getUniqueId());
        menuCooldown.remove(p.getUniqueId());
        pl.dungeons().onLeave(p);
        // store.inside stays set on purpose: the next join (even after a crash) pulls them out safely
    }

    /** Join-time recovery after disconnect / restart / crash. */
    public void recoverOnJoin(Player p) {
        boolean flagged = pl.store().inside(p.getUniqueId()) != null;
        boolean inDungeonWorld = pl.dungeons().isDungeonWorld(p.getWorld().getName());
        if (flagged || (inDungeonWorld && !Access.isAdmin(p))) returnToLobby(p, "quiet");
    }

    // ------------------------------------------------------------------ recall sigil

    public void startRecall(Player p) {
        UUID id = p.getUniqueId();
        if (!hasSession(p) || recalls.containsKey(id)) return;
        int secs = Math.max(1, pl.getConfig().getInt("recall.channel-seconds", 5));
        Location start = p.getLocation();
        p.sendMessage(Msg.mm(Msg.PREFIX + "<gray>The sigil hums. Hold still..."));
        BukkitTask t = new BukkitRunnable() {
            int left = secs * 2;

            @Override
            public void run() {
                if (!p.isOnline() || !hasSession(p) || p.getLocation().getWorld() != start.getWorld()
                        || p.getLocation().distanceSquared(start) > 0.6) {
                    cancelRecall(id);
                    if (p.isOnline()) p.sendActionBar(Msg.mm("<red>Recall broken."));
                    return;
                }
                left--;
                p.getWorld().spawnParticle(Particle.ENCHANT, p.getLocation().add(0, 1, 0), 25, 0.5, 1, 0.5, 0.8);
                p.sendActionBar(Msg.mm("<gradient:#7a5cff:#2de2e6>Recalling... " + (int) Math.ceil(left / 2.0) + "s"));
                if (left <= 0) {
                    recalls.remove(id);
                    cancel();
                    returnToLobby(p, "recall");
                }
            }
        }.runTaskTimer(pl, 10L, 10L);
        recalls.put(id, t);
    }

    public boolean isRecalling(Player p) { return recalls.containsKey(p.getUniqueId()); }

    public void cancelRecall(UUID id) {
        BukkitTask t = recalls.remove(id);
        if (t != null) t.cancel();
    }

    // ------------------------------------------------------------------ the only teleport path

    private boolean tp(Player p, Location to) {
        UUID id = p.getUniqueId();
        tokens.add(id);
        try {
            return p.teleport(to, PlayerTeleportEvent.TeleportCause.PLUGIN);
        } finally {
            tokens.remove(id);
        }
    }

    /** Admin-only: used by /vyrnth player send. Same pipeline, no portal-distance requirement. */
    public String adminSend(Player target, DungeonDef d) {
        return enter(target, d, false, true);
    }

    public void shutdown() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (hasSession(p)) returnToLobby(p, "quiet");
        }
        for (UUID id : new ArrayList<>(recalls.keySet())) cancelRecall(id);
    }
}
