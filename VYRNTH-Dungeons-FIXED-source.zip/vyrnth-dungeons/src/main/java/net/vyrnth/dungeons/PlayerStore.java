package net.vyrnth.dungeons;

import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Per-player progression + crash-recovery state (playerdata/<uuid>.yml). */
public final class PlayerStore {
    private final VyrnthPlugin pl;
    private final File dir;
    private final Map<UUID, YamlConfiguration> cache = new ConcurrentHashMap<>();

    public PlayerStore(VyrnthPlugin pl) {
        this.pl = pl;
        this.dir = new File(pl.getDataFolder(), "playerdata");
        dir.mkdirs();
    }

    private File file(UUID id) { return new File(dir, id + ".yml"); }

    private YamlConfiguration cfg(UUID id) {
        return cache.computeIfAbsent(id, k -> YamlConfiguration.loadConfiguration(file(k)));
    }

    private void save(UUID id) {
        try { cfg(id).save(file(id)); }
        catch (IOException e) { pl.getLogger().warning("Could not save playerdata " + id + ": " + e.getMessage()); }
    }

    public void unload(UUID id) { cache.remove(id); }

    // progression --------------------------------------------------------------
    public int stage(UUID id, String d) { return cfg(id).getInt("dungeons." + d + ".stage", 0); }
    public int bosses(UUID id, String d) { return cfg(id).getInt("dungeons." + d + ".bosses", 0); }
    public int clears(UUID id, String d) { return cfg(id).getInt("dungeons." + d + ".clears", 0); }
    public long best(UUID id, String d) { return cfg(id).getLong("dungeons." + d + ".best-seconds", 0); }

    public void setStage(UUID id, String d, int v) {
        cfg(id).set("dungeons." + d + ".stage", Math.max(0, v));
        save(id);
    }

    public boolean raiseStage(UUID id, String d, int v) {
        if (v <= stage(id, d)) return false;
        setStage(id, d, v);
        return true;
    }

    public void recordClear(UUID id, String d, long seconds) {
        YamlConfiguration c = cfg(id);
        String p = "dungeons." + d + ".";
        c.set(p + "bosses", c.getInt(p + "bosses", 0) + 1);
        c.set(p + "clears", c.getInt(p + "clears", 0) + 1);
        long best = c.getLong(p + "best-seconds", 0);
        if (best == 0 || seconds < best) c.set(p + "best-seconds", seconds);
        save(id);
    }

    public void reset(UUID id, String dungeonOrNull) {
        YamlConfiguration c = cfg(id);
        if (dungeonOrNull == null) c.set("dungeons", null);
        else c.set("dungeons." + dungeonOrNull, null);
        save(id);
    }

    // session recovery ---------------------------------------------------------
    public String inside(UUID id) { return cfg(id).getString("inside"); }

    public GameMode storedMode(UUID id) {
        try { return GameMode.valueOf(cfg(id).getString("gamemode", "SURVIVAL")); }
        catch (IllegalArgumentException e) { return GameMode.SURVIVAL; }
    }

    public void setInside(UUID id, String dungeon, GameMode previous) {
        YamlConfiguration c = cfg(id);
        c.set("inside", dungeon);
        c.set("gamemode", previous.name());
        save(id);
    }

    public void clearInside(UUID id) {
        YamlConfiguration c = cfg(id);
        if (c.get("inside") == null) return;
        c.set("inside", null);
        c.set("gamemode", null);
        save(id);
    }

    public ConfigurationSection raw(UUID id) { return cfg(id); }
}
