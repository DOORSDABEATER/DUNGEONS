package net.vyrnth.dungeons;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** One dungeon, loaded from dungeons/<id>.yml. */
public final class DungeonDef {
    public record Mob(String mythic, EntityType fallback, int weight) {}

    private final String id;
    private final File file;
    private final YamlConfiguration cfg;

    public DungeonDef(String id, File file) {
        this.id = id;
        this.file = file;
        this.cfg = YamlConfiguration.loadConfiguration(file);
    }

    public String id() { return id; }
    public String display() { return cfg.getString("display-name", id); }
    public List<String> description() { return cfg.getStringList("description"); }
    public boolean enabled() { return cfg.getBoolean("enabled", true); }
    public void setEnabled(boolean v) { cfg.set("enabled", v); save(); }
    public String iconModel() { return cfg.getString("icon-model", "vyrnth:icon_default"); }
    public String worldName() { return cfg.getString("world", "vyrnth_" + id).toLowerCase(); }
    public long seed() { return cfg.getLong("seed", id.hashCode()); }
    public int chambers() { return Math.max(1, Math.min(12, cfg.getInt("chambers", 5))); }
    public int difficulty() { return Math.max(1, Math.min(5, cfg.getInt("difficulty", 2))); }

    public List<Mob> mobs() {
        List<Mob> out = new ArrayList<>();
        for (Map<?, ?> m : cfg.getMapList("mobs")) {
            Object my = m.get("mythic");
            Object fb = m.get("fallback");
            Object w = m.get("weight");
            out.add(new Mob(my == null ? null : my.toString(), type(fb == null ? "ZOMBIE" : fb.toString()),
                    w instanceof Number n ? Math.max(1, n.intValue()) : 1));
        }
        if (out.isEmpty()) out.add(new Mob(null, EntityType.ZOMBIE, 1));
        return out;
    }

    public String bossMythic() { return cfg.getString("boss.mythic", ""); }
    public EntityType bossFallback() { return type(cfg.getString("boss.fallback", "WITHER_SKELETON")); }
    public double bossFallbackHealth() { return cfg.getDouble("boss.fallback-health", 600); }
    public String bossName() { return cfg.getString("boss.name", "<dark_purple>The Hollow King"); }

    /** threshold % -> skill, highest threshold first. */
    public Map<Integer, String> bossPhases() {
        Map<Integer, String> out = new TreeMap<>((a, b) -> b - a);
        ConfigurationSection s = cfg.getConfigurationSection("boss.phases");
        if (s != null) for (String k : s.getKeys(false)) {
            try { out.put(Integer.parseInt(k), s.getString(k, "")); } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    // rewards -----------------------------------------------------------------
    public int rewardXp() { return cfg.getInt("rewards.xp", 0); }
    public void setRewardXp(int v) { cfg.set("rewards.xp", Math.max(0, v)); save(); }
    public List<String> rewardCommands() { return new ArrayList<>(cfg.getStringList("rewards.commands")); }
    public void setRewardCommands(List<String> l) { cfg.set("rewards.commands", l); save(); }

    public List<ItemStack> rewardItems() {
        List<ItemStack> out = new ArrayList<>();
        for (Object o : cfg.getList("rewards.items", List.of())) if (o instanceof ItemStack it) out.add(it);
        return out;
    }

    public void setRewardItems(List<ItemStack> l) { cfg.set("rewards.items", l); save(); }

    public Map<String, Double> relicDrops() {
        Map<String, Double> out = new LinkedHashMap<>();
        ConfigurationSection s = cfg.getConfigurationSection("rewards.relic-drops");
        if (s != null) for (String k : s.getKeys(false)) out.put(k, s.getDouble(k));
        return out;
    }

    public void save() {
        try { cfg.save(file); } catch (IOException e) { throw new IllegalStateException("Could not save " + file.getName()); }
    }

    private static EntityType type(String s) {
        try { return EntityType.valueOf(s.toUpperCase()); } catch (IllegalArgumentException e) { return EntityType.ZOMBIE; }
    }
}
