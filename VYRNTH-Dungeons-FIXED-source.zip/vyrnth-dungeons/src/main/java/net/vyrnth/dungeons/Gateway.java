package net.vyrnth.dungeons;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Light;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * The VYRNTH gateway: an 11 x 11 x 7 ancient arch built ONLY from custom blocks (plus invisible light
 * blocks), with an animated membrane (item display skinned by the resource pack) in the opening.
 * Used for the lobby portal and for the return gate in the dungeon antechamber.
 */
public final class Gateway {
    private Gateway() {}

    /** Clear/footprint volume: a -5..5, d -3..3, y 0..10. */
    public static final int RA = 5, RD = 3, HT = 10;
    public static final String FX_TAG = "vyrnth_fx";

    private static final BlockData AIR = Material.AIR.createBlockData();

    public static BlockData light(int level) {
        Light l = (Light) Material.LIGHT.createBlockData();
        l.setLevel(level);
        return l;
    }

    public static void build(Frame f, Sink s) {
        // footprint: plinth floor (y=0) and cleared volume above it
        for (int a = -RA; a <= RA; a++) {
            for (int d = -RD; d <= RD; d++) {
                boolean border = Math.abs(a) == RA || Math.abs(d) == RD;
                boolean aisle = Math.abs(a) <= 1;
                BlockData floor = border ? CBlock.GATEWAY_STONE.data()
                        : aisle ? CBlock.ECLIPSE_TILE.data() : CBlock.SIGIL_FLOOR.data();
                f.put(s, a, 0, d, floor);
                for (int y = 1; y <= HT; y++) f.put(s, a, y, d, AIR);
            }
        }
        for (int sg = -1; sg <= 1; sg += 2) {
            for (int d = -1; d <= 1; d++) {
                for (int y = 1; y <= 6; y++)
                    f.put(s, 2 * sg, y, d, y == 3 ? CBlock.GATEWAY_GLYPH.data() : CBlock.GATEWAY_STONE.data());
                for (int y = 1; y <= 8; y++) f.put(s, 3 * sg, y, d, CBlock.GILDED_PILLAR.data());
                for (int y = 1; y <= 2; y++) f.put(s, 4 * sg, y, d, CBlock.RUIN_BRICK.data());
            }
            f.put(s, 5 * sg, 1, 0, CBlock.BRAZIER.data());
            f.put(s, 5 * sg, 2, 0, light(14));
            f.put(s, 4 * sg, 1, 2, CBlock.BRAZIER.data());
            f.put(s, 4 * sg, 2, 2, light(14));
        }
        for (int d = -1; d <= 1; d++) {
            for (int a = -1; a <= 1; a++) f.put(s, a, 6, d, CBlock.GATEWAY_STONE.data());
            for (int a = -2; a <= 2; a++)
                f.put(s, a, 7, d, a == 0 ? CBlock.GATEWAY_GLYPH.data() : CBlock.CARVED_RUNESTONE.data());
            for (int a = -2; a <= 2; a++) f.put(s, a, 8, d, CBlock.RUIN_BRICK.data());
            for (int a = -3; a <= 3; a++) f.put(s, a, 9, d, CBlock.ANCIENT_GOLD.data());
        }
        f.put(s, 0, 10, 0, CBlock.GATEWAY_GLYPH.data());
        // soft glow inside the opening (light blocks are invisible and non-solid)
        f.put(s, 0, 2, 0, light(12));
        f.put(s, 0, 4, 0, light(12));
    }

    public static Location openingCenter(Frame f) {
        return new Location(f.world, f.x(0, 0) + 0.5, f.oy + 3.5, f.z(0, 0) + 0.5);
    }

    /** Spawns the animated membrane (3 wide x 5 tall) inside the arch opening. */
    public static ItemDisplay spawnMembrane(Frame f, String tag) {
        Location loc = openingCenter(f);
        loc.setYaw(f.fx != 0 ? 90f : 0f);
        loc.setPitch(0f);
        return f.world.spawn(loc, ItemDisplay.class, d -> {
            ItemStack it = new ItemStack(Material.ECHO_SHARD); // non-block base => translucent rendering
            ItemMeta m = it.getItemMeta();
            m.setItemModel(new NamespacedKey("vyrnth", "portal_membrane"));
            it.setItemMeta(m);
            d.setItemStack(it);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            d.setBillboard(Display.Billboard.FIXED);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setViewRange(2.0f);
            d.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f), new AxisAngle4f(), new Vector3f(3f, 5f, 1f), new AxisAngle4f()));
            d.addScoreboardTag(FX_TAG);
            d.addScoreboardTag(tag);
        });
    }
}
