package net.vyrnth.dungeons;

import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/** Loads dungeon definitions, owns their (void) worlds, builds them and runs their instances. */
public final class DungeonManager {
    /** Dungeon worlds MUST use this prefix: it guarantees we can never build in / wipe a normal world. */
    public static final String WORLD_PREFIX = "vyrnth_";
    private static final Pattern WORLD_OK = Pattern.compile("^vyrnth_[a-z0-9_]+$");

    private final VyrnthPlugin pl;
    private final Map<String, DungeonDef> defs = new LinkedHashMap<>();
    private final Map<String, Instance> instances = new HashMap<>();
    private final Set<String> worlds = new HashSet<>();
    private final Set<String> building = new HashSet<>();

    public DungeonManager(VyrnthPlugin pl) {
        this.pl = pl;
    }

    // ------------------------------------------------------------------ loading

    public void loadAll() {
        for (Instance i : instances.values()) {
            i.stop();
            if (i.layout() != null) i.resetAll();
        }
        defs.clear();
        instances.clear();
        worlds.clear();
        File dir = new File(pl.getDataFolder(), "dungeons");
        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return;
        for (File f : files) {
            String id = f.getName().substring(0, f.getName().length() - 4).toLowerCase();
            DungeonDef d = new DungeonDef(id, f);
            if (!WORLD_OK.matcher(d.worldName()).matches()) {
                pl.getLogger().warning("Dungeon '" + id + "' skipped: world name must match vyrnth_[a-z0-9_]+ (got '" + d.worldName() + "').");
                continue;
            }
            defs.put(id, d);
            worlds.add(d.worldName());
            Instance inst = new Instance(pl, d);
            instances.put(id, inst);
            if (isBuilt(id)) {
                World w = ensureWorld(d);
                if (w != null) {
                    inst.attach(w);
                    inst.start();
                }
            }
        }
        pl.getLogger().info("Loaded " + defs.size() + " dungeon(s).");
    }

    public World ensureWorld(DungeonDef d) {
        World w = Bukkit.getWorld(d.worldName());
        if (w == null) {
            w = new WorldCreator(d.worldName())
                    .environment(World.Environment.NORMAL)
                    .generator(new VoidGenerator())
                    .generateStructures(false)
                    .createWorld();
        }
        if (w != null) configure(w);
        return w;
    }

    private void configure(World w) {
        w.setPVP(false);
        w.setStorm(false);
        w.setThundering(false);
        w.setTime(18000);
        w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        w.setGameRule(GameRule.MOB_GRIEFING, false);
        w.setGameRule(GameRule.DO_FIRE_TICK, false);
        w.setSpawnLocation(10, Layout.Y0 + 1, 0);
        // clean up mobs a crash may have left behind
        for (org.bukkit.entity.LivingEntity le : w.getEntitiesByClass(org.bukkit.entity.LivingEntity.class))
            if (le.getPersistentDataContainer().has(Keys.MOB, PersistentDataType.BYTE)) le.remove();
    }

    // ------------------------------------------------------------------ queries

    public boolean isDungeonWorld(String name) { return worlds.contains(name.toLowerCase()); }
    public boolean isBuilt(String id) { return pl.data().getBoolean("built." + id, false); }
    public boolean isBuilding(String id) { return building.contains(id); }
    public DungeonDef def(String id) { return id == null ? null : defs.get(id.toLowerCase()); }
    public Instance instance(String id) { return id == null ? null : instances.get(id.toLowerCase()); }
    public Collection<DungeonDef> defs() { return defs.values(); }

    public List<DungeonDef> enabledDefs() {
        List<DungeonDef> out = new ArrayList<>();
        for (DungeonDef d : defs.values()) {
            Instance i = instances.get(d.id());
            if (d.enabled() && i != null && i.ready()) out.add(d);
        }
        return out;
    }

    // ------------------------------------------------------------------ building

    /** fresh=true wipes the world folder first (needed if seed/chambers changed). */
    public void build(DungeonDef d, CommandSender who, boolean fresh) {
        String id = d.id();
        if (building.contains(id)) { Msg.err(who, "Already forging " + id + "."); return; }
        // Stop and clean the current instance BEFORE unloading/deleting its world.
        // resetAll() writes seal blocks and removes tagged entities through the old World reference.
        Instance old = instances.get(id);
        World previousWorld = Bukkit.getWorld(d.worldName());
        if (previousWorld != null) {
            for (Player p : new ArrayList<>(previousWorld.getPlayers()))
                pl.access().returnToLobby(p, "rebuild");
        }
        if (old != null) {
            old.stop();
            if (old.layout() != null) old.resetAll();
        }

        if (fresh) {
            // Remove the return-gate display entities while their world is still loaded.
            pl.portals().forget("return_" + id);
            String err = wipe(d);
            if (err != null) {
                // The world was not wiped; restore its return gate and instance loop.
                if (previousWorld != null && Bukkit.getWorld(d.worldName()) == previousWorld) {
                    pl.portals().registerReturn("return_" + id, previousWorld,
                            Layout.GATE_X, Layout.Y0, Layout.GATE_Z, BlockFace.EAST);
                    if (old != null) old.start();
                }
                Msg.err(who, err);
                return;
            }
            instances.remove(id);
        }
        World w = ensureWorld(d);
        if (w == null) {
            if (old != null && previousWorld != null && Bukkit.getWorld(d.worldName()) == previousWorld) {
                instances.put(id, old);
                old.start();
            }
            Msg.err(who, "Could not create world " + d.worldName());
            return;
        }
        if (!fresh) pl.portals().forget("return_" + id);
        pl.data().set("built." + id, false);
        pl.saveData();

        Layout lay = new Layout(d);
        Map<Long, BlockData> blocks = lay.paint(w);
        Iterator<Map.Entry<Long, BlockData>> it = blocks.entrySet().iterator();
        int total = blocks.size();
        int per = Math.max(200, pl.getConfig().getInt("dungeon.blocks-per-tick", 3000));
        building.add(id);
        Msg.send(who, "Forging <white>" + id + "</white>: " + total + " blocks...");
        new BukkitRunnable() {
            int done = 0, lastDecile = -1;

            @Override
            public void run() {
                try {
                    int n = 0;
                    while (it.hasNext() && n++ < per) {
                        Map.Entry<Long, BlockData> e = it.next();
                        long k = e.getKey();
                        w.getBlockAt(Layout.ux(k), Layout.uy(k), Layout.uz(k)).setBlockData(e.getValue(), false);
                        done++;
                    }
                    int decile = (int) (done * 10L / Math.max(1, total));
                    if (decile != lastDecile) { lastDecile = decile; Msg.send(who, "Forging... " + decile * 10 + "%"); }
                    if (!it.hasNext()) { cancel(); finish(d, w, who); }
                } catch (Exception ex) {
                    cancel();
                    building.remove(id);
                    Msg.err(who, "Build failed: " + ex.getMessage());
                    pl.getLogger().warning("Dungeon build failed: " + ex);
                }
            }
        }.runTaskTimer(pl, 1L, 1L);
    }

    private void finish(DungeonDef d, World w, CommandSender who) {
        w.setSpawnLocation(10, Layout.Y0 + 1, 0);
        pl.data().set("built." + d.id(), true);
        pl.saveData();
        pl.portals().registerReturn("return_" + d.id(), w, Layout.GATE_X, Layout.Y0, Layout.GATE_Z, BlockFace.EAST);
        Instance inst = new Instance(pl, d);
        inst.attach(w);
        inst.start();
        instances.put(d.id(), inst);
        building.remove(d.id());
        Msg.send(who, "<green>" + d.id() + " is forged.</green> It now appears in the lobby gateway menu.");
    }

    private String wipe(DungeonDef d) {
        World w = Bukkit.getWorld(d.worldName());
        File folder = w != null ? w.getWorldFolder() : new File(Bukkit.getWorldContainer(), d.worldName());
        if (!WORLD_OK.matcher(d.worldName()).matches()) return "Refusing to wipe a non-VYRNTH world.";
        if (w != null) {
            for (Player p : w.getPlayers()) pl.access().returnToLobby(p, "rebuild");
            if (!Bukkit.unloadWorld(w, false)) return "Could not unload " + d.worldName() + " (players still inside?).";
        }
        if (folder.exists()) {
            try (var walk = Files.walk(folder.toPath())) {
                for (Path p : walk.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);
            } catch (IOException e) {
                return "Could not delete world folder: " + e.getMessage();
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ hooks

    public void onLeave(Player p) {
        for (Instance i : instances.values()) i.onLeave(p);
    }

    public void onEntityDeath(EntityDeathEvent e) {
        if (!e.getEntity().getPersistentDataContainer().has(Keys.MOB, PersistentDataType.BYTE)) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        for (Instance i : instances.values()) i.onEntityDeath(e.getEntity());
    }

    public void shutdown() {
        for (Instance i : instances.values()) {
            i.stop();
            if (i.layout() != null) i.resetAll();
        }
    }
}
