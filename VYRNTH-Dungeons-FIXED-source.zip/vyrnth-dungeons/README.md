# VYRNTH Dungeons

Ancient-realm dungeon plugin for Paper. **OPs control the dungeons with commands. Players discover them through a
physical gateway in the main lobby.** There is no player command, anywhere.

## What you get
| Piece | Where |
|---|---|
| OP-only admin system (`/vyrnth ...`) | `Access.java`, `AdminCommand.java`, `Guards.java` |
| Lobby gateway (custom-block arch, animated membrane, particles, sounds, menu) | `Gateway.java`, `PortalManager.java`, `PortalMenu.java` |
| Entry / return / recovery / teleport validation | `AccessService.java`, `Guards.java` |
| Procedural dungeon "The Sunken Reliquary" (antechamber + 5 chambers + boss arena) | `Layout.java`, `DungeonManager.java`, `Instance.java` |
| 14 custom blocks (resource pack) | `CBlock.java`, `resourcepack/generate_pack.py` |
| MythicMobs mobs + boss with phases | `mythicmobs/`, `MythicBridge.java` |
| Relics, rewards, timed events, progression | `RelicManager`, `Instance`, `EventManager`, `PlayerStore` |

## Install (5 steps)
1. **Build**: `mvn package` (Java 21). Set `<paper.version>` in `pom.xml` to your server's Paper API. Drop `target/VyrnthDungeons.jar` in `plugins/`.
2. **Resource pack**: `python3 resourcepack/generate_pack.py VYRNTH-Resourcepack --zip`, host the zip, set it as `resource-pack=` in `server.properties` (required: it is what makes the blocks look custom). If your client says the pack is for a different version, change `pack_format` in `pack.mcmeta`.
3. **Paper setting (required)**: `config/paper-global.yml` -> `block-updates.disable-noteblock-updates: true`, then restart. The plugin warns in console if it is off.
4. **MythicMobs (optional)**: copy `mythicmobs/Mobs/*` and `mythicmobs/Skills/*` into `plugins/MythicMobs/`, run `/mm reload`. Without MythicMobs the plugin falls back to vanilla mobs with scaled stats.
5. **In game (as OP, in your main lobby)**:
   ```
   /vyrnth lobby set            stand at the lobby spawn
   /vyrnth portal build         stand ~5 blocks from where the gateway goes, facing it (needs an open 11x11x7 area; undo with portal remove)
   /vyrnth dungeon build reliquary
   ```
   Done. Players walk into / click the gateway, pick a dungeon, descend.

## Security model
- **Admin = server OP or console. Hard-coded** (`Access.isAdmin`). No config option, no permission node, so LuckPerms etc. cannot grant it. Command blocks are denied.
- Checked **three times**: command executor, every subcommand handler, and a `PlayerCommandPreprocessEvent` guard that catches aliases / `vyrnth:vyrnth`. Tab-completion hiding is cosmetic only.
- **All teleports into dungeon worlds are validated server-side**: a `PlayerTeleportEvent` guard cancels any non-admin teleport into a dungeon world unless `AccessService` set a one-shot token for that exact player during an approved entry. This also blocks ender pearls, chorus fruit, other plugins' `/tp`, `/home`, nether portals, etc.
- Portal entry re-validates on the server: right world, within `max-distance-from-portal` of a real gateway, cooldown, dungeon enabled+built, no existing session.
- Dungeon worlds: no block break/place/buckets/explosions for non-OPs; PvP off; non-OP commands blocked (small allow-list in config); adventure mode.
- Dungeon world names must start with `vyrnth_` (build/rebuild can never touch a normal world).

## Return & failure handling
- **Return gate** in the antechamber (walk in), **Recall Sigil** item (right-click, hold still 5s), **auto-return** 20s after the boss dies, **death** respawns in the lobby (progress kept).
- Disconnect / crash / restart: sessions are flagged on disk; on next join the player is pulled to the lobby and their game mode restored.
- Shared dungeon world: rooms spawn waves when entered, seals open when cleared, everything resets after the dungeon sits empty (`idle-reset-seconds`).

## Admin command cheat sheet
`/vyrnth help` lists everything: lobby, portal, dungeon (build/rebuild/enable/disable/reset/tp), boss (spawn/kill/summon),
reward (addcmd/additem/xp/...), relic (give/take), progress (get/set/reset), event (start/stop), player (list/kick/send), block (give), debug, reload.

## Adding another dungeon
Copy `plugins/VyrnthDungeons/dungeons/reliquary.yml` to `<newid>.yml`, change `display-name`, `world` (`vyrnth_<name>`), `seed`, `chambers`, mobs/boss, `/vyrnth reload`, `/vyrnth dungeon build <newid>`. It appears in the gateway menu automatically.

## Honest notes
- Written for Paper 1.21.4+ API; I could not run a Minecraft server here, so **treat this as a first build that needs a test pass on a dev server** (compile errors against your exact Paper/MythicMobs versions are possible; MythicMobs API use is isolated in `MythicBridge.java`).
- MythicMobs YAML follows 5.x syntax from memory; check console on `/mm reload`.
- Custom blocks are note-block states: vanilla note-block tuning is disabled for non-OPs (otherwise players could tune into custom states). The Light blocks (invisible) are the only vanilla-ish blocks used.
- Textures are procedural placeholders; replace PNGs in the pack with hand-painted art any time.

## Patch note (2026-11-16)

The dungeon rebuild lifecycle was corrected: the active instance is now stopped and reset while its world is still loaded; its return-gate visuals are removed before a fresh world unload; and the old instance is removed from the manager after a successful wipe. If the wipe fails while the old world remains loaded, the return gate and instance task are restored.
